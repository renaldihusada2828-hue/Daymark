# Daymark 2.1

Native Android planner + habit tracker, offline.

## 2.1
- New Daymark launcher icon based on the supplied logo.
- Habit icons redesigned as a consistent dark/mint icon set.
- Habit targets support multiple check-ins (for example 4× meals or 3× job applications).
- Daily To-Do routine is seeded per date.
- Date navigation, streaks, weekly progress, settings, profile, backup, reset, and first-run tutorial.
- No remote images or AI-generated content is required at runtime.
