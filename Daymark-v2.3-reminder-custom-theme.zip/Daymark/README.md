# Daymark v2.3

Native Android Kotlin + Jetpack Compose, offline-first.

## v2.3
- Task reminders and daily habit reminders via Android notifications.
- Notification permission on Android 13+.
- Reminders are restored after device reboot/app update.
- Custom accent theme with presets and HEX color input.
- No ads, billing, or network dependency.

## Build
GitHub Actions builds a debug APK with JDK 17 and Gradle 8.11.1.
