package com.daymark.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object ReminderScheduler {
    private const val TASK_BASE = 50000
    private const val HABIT_BASE = 90000
    private const val CHANNEL_ID = "daymark_reminders"

    fun ensureChannel(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Daymark reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Pengingat To-Do dan habit Daymark"
            })
        }
    }

    fun scheduleTask(context: Context, task: Task) {
        if (!task.reminderEnabled || task.reminderTime.isBlank()) return
        val millis = nextMillis(task.date, task.reminderTime, false) ?: return
        set(context, TASK_BASE + (task.id % 40000).toInt(), millis, task.title, "Waktunya mengerjakan To-Do Daymark")
    }

    fun scheduleHabit(context: Context, habit: Habit) {
        if (!habit.reminderEnabled || habit.reminderTime.isBlank()) return
        val millis = nextMillis(todayString(), habit.reminderTime, true) ?: return
        set(context, HABIT_BASE + stableId(habit.id), millis, habit.name, "Pengingat habit harian")
    }

    fun cancelTask(context: Context, id: Long) = cancel(context, TASK_BASE + (id % 40000).toInt())
    fun cancelHabit(context: Context, id: String) = cancel(context, HABIT_BASE + stableId(id))

    fun rescheduleAll(context: Context) {
        ensureChannel(context)
        val p = context.getSharedPreferences("daymark_v21", Context.MODE_PRIVATE)
        val tasks = try { org.json.JSONArray(p.getString("tasks", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        for (i in 0 until tasks.length()) {
            val o = tasks.getJSONObject(i)
            val t = Task(o.getLong("id"), o.getString("date"), o.getString("title"), o.optString("time"), o.optBoolean("done"), o.optInt("priority",0), o.optString("habitId").takeIf { it.isNotBlank() }, o.optBoolean("reminderEnabled",false), o.optString("reminderTime"))
            if (!t.done && t.date >= todayString()) scheduleTask(context, t)
        }
        val habits = try { org.json.JSONArray(p.getString("habits", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        for (i in 0 until habits.length()) {
            val o = habits.getJSONObject(i)
            val h = Habit(o.getString("id"), o.getString("name"), o.optString("icon","other"), o.optInt("target",1), emptyMap(), o.optBoolean("reminderEnabled",false), o.optString("reminderTime","09:00"))
            scheduleHabit(context, h)
        }
    }

    private fun set(context: Context, request: Int, at: Long, title: String, body: String) {
        ensureChannel(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply { putExtra("title", title); putExtra("body", body); putExtra("habitRequest", request >= HABIT_BASE) }
        val pi = PendingIntent.getBroadcast(context, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    private fun cancel(context: Context, request: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, request, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
    }

    private fun stableId(s: String): Int = (s.hashCode() and 0x7FFF)

    private fun nextMillis(date: String, time: String, daily: Boolean): Long? {
        val parts = time.trim().split(":")
        if (parts.size != 2) return null
        val hour = parts[0].toIntOrNull() ?: return null
        val minute = parts[1].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        val c = Calendar.getInstance()
        if (daily) { c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1) }
        else { val d = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date) } catch (_: Exception) { null } ?: return null; c.time = d; c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); if (c.timeInMillis <= System.currentTimeMillis()) return null }
        return c.timeInMillis
    }

    private fun todayString(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.ensureChannel(context)
        val title = intent.getStringExtra("title") ?: "Daymark"
        val body = intent.getStringExtra("body") ?: "Ada pengingat untukmu."
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, "daymark_reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), notification)
        if (intent.getBooleanExtra("habitRequest", false)) {
            // The next daily reminder is recreated from stored data after each trigger.
            ReminderScheduler.rescheduleAll(context)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) ReminderScheduler.rescheduleAll(context)
    }
}
