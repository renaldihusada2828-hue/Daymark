package com.daymark.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private val Ink=Color(0xFF171A19); private val Paper=Color(0xFFF5F4EF); private val Card=Color(0xFFFFFEFA)
private val Muted=Color(0xFF737772); private val Line=Color(0xFFE2E1DA); private val Accent=Color(0xFFC9F36B)

private data class Task(val id:Long,val date:String,val title:String,val time:String,val done:Boolean)
private data class Habit(val id:Long,val name:String,val icon:String,val dates:Set<String>)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{Daymark(this)}}
}

@Composable private fun Daymark(ctx:Context){
 val store=remember{Store(ctx)}
 var tasks by remember{mutableStateOf(store.tasks())}; var habits by remember{mutableStateOf(store.habits())}
 var water by remember{mutableStateOf(store.water())}; var meals by remember{mutableStateOf(store.meals())}
 var date by remember{mutableStateOf(LocalDate.now())}; var tab by remember{mutableIntStateOf(0)}
 var name by remember{mutableStateOf(store.name())}; var dark by remember{mutableStateOf(store.dark())}
 var tutorial by remember{mutableStateOf(!store.seenTutorial())}; var dialog by remember{mutableStateOf<String?>(null)}
 fun save(){store.saveTasks(tasks);store.saveHabits(habits);store.saveWater(water);store.saveMeals(meals);store.saveName(name);store.saveDark(dark)}
 fun toggleTask(id:Long){tasks=tasks.map{if(it.id==id&&it.date==date.toString())it.copy(done=!it.done)else it};save()}
 fun toggleHabit(id:Long){val k=date.toString();habits=habits.map{if(it.id!=id)it else it.copy(dates=it.dates.toMutableSet().also{d->if(!d.add(k))d.remove(k)})};save()}
 val scheme=if(dark)darkColorScheme(primary=Accent,background=Color(0xFF121413),surface=Color(0xFF1B1E1C),onSurface=Color.White) else lightColorScheme(primary=Ink,background=Paper,surface=Card)
 MaterialTheme(colorScheme=scheme){
  Surface(Modifier.fillMaxSize()){Column{
   Top(date,tab,{date=LocalDate.now();tab=0})
   Box(Modifier.weight(1f)){when(tab){
    0->Home(date,tasks.filter{it.date==date.toString()},habits,water[date.toString()]?:0,meals[date.toString()]?:emptySet(),
      {date=date.minusDays(1)},{date=date.plusDays(1)},{toggleTask(it)},{toggleHabit(it)},
      {dialog="task"},{dialog="habit"},{water=water.toMutableMap().also{it[date.toString()]=((it[date.toString()]?:0)+1).coerceAtMost(12)};save()},
      {water=water.toMutableMap().also{it[date.toString()]=((it[date.toString()]?:0)-1).coerceAtLeast(0)};save()},
      {m->meals=meals.toMutableMap().also{it[date.toString()]=((it[date.toString()]?:emptySet()).toMutableSet().also{s->if(!s.add(m))s.remove(m)})};save()})
    1->Habits(habits,date,{toggleHabit(it)},{dialog="habit"})
    2->Progress(tasks,habits,water,meals)
    else->More(name,dark,{dialog="name"},{dark=!dark;save()},{tutorial=true;dialog=null},{store.export(tasks,habits,water,meals)})
   }}
   Nav(tab){tab=it}
  }}
  if(tutorial)Tutorial{store.setTutorial();tutorial=false}
  when(dialog){
   "task"->TextDialog("Tambah To-Do","Contoh: Belajar coding", ""){t->tasks=tasks+Task(System.currentTimeMillis(),date.toString(),t,"",false);save();dialog=null}
   "habit"->HabitDialog{n,i->habits=habits+Habit(System.currentTimeMillis(),n,i,emptySet());save();dialog=null}
   "name"->TextDialog("Nama kamu","Nama",name){n->name=n;save();dialog=null}
  }
 }
}

@Composable private fun Top(date:LocalDate,tab:Int,today:()->Unit){
 Column(Modifier.padding(horizontal=22.dp,vertical=15.dp)){Row(verticalAlignment=Alignment.CenterVertically){
  Text("DAYMARK",fontSize=13.sp,fontWeight=FontWeight.Black,letterSpacing=2.2.sp);Spacer(Modifier.weight(1f))
  if(date!=LocalDate.now())Text("Hari ini",Modifier.clip(RoundedCornerShape(10.dp)).background(Ink).clickable{today()}.padding(10.dp),color=Accent,fontSize=11.sp,fontWeight=FontWeight.Bold)
 };Spacer(Modifier.height(13.dp))
  val title=when(tab){0->date.dayOfWeek.getDisplayName(TextStyle.FULL,Locale("id","ID")).replaceFirstChar{it.uppercase()};1->"Habits";2->"Progress";else->"Lainnya"}
  Text(title,fontSize=29.sp,fontWeight=FontWeight.Black);Text(if(tab==0)date.format(DateTimeFormatter.ofPattern("d MMMM yyyy",Locale("id","ID"))) else when(tab){1->"Konsisten, bukan sempurna.";2->"Lihat pola, bukan sekadar angka.";else->"Atur Daymark sesuai caramu."},color=Muted,fontSize=14.sp)
 }
}

@Composable private fun Home(date:LocalDate,tasks:List<Task>,habits:List<Habit>,w:Int,meal:Set<String>,prev:()->Unit,next:()->Unit,tTask:(Long)->Unit,tHabit:(Long)->Unit,addTask:()->Unit,addHabit:()->Unit,plus:()->Unit,minus:()->Unit,toggleMeal:(String)->Unit){
 val done=tasks.count{it.done};val total=tasks.size;val rate=if(total==0)0 else done*100/total
 LazyColumn(contentPadding=PaddingValues(22.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
  item{Row(verticalAlignment=Alignment.CenterVertically){DaySwitch(date,prev,next);Spacer(Modifier.weight(1f));Small("+ tugas",addTask)}}
  item{WelcomeCard(date,rate,done,total)}
  item{Section("KEBUTUHAN HARIAN")}
  item{WaterCard(w,plus,minus)}
  item{MealCard(meal,toggleMeal)}
  item{Section("TO-DO HARI INI")}
  if(tasks.isEmpty())item{Empty("Hari masih kosong","Tambahkan satu tugas kecil untuk mulai.")}
  items(tasks,key={it.id}){TaskRow(it,tTask)}
  item{Row(verticalAlignment=Alignment.CenterVertically){Section("HABIT");Spacer(Modifier.weight(1f));Small("+ habit",addHabit)}}
  items(habits,key={it.id}){HabitRow(it,date,tHabit)}
 }
}
@Composable private fun WelcomeCard(date:LocalDate,rate:Int,done:Int,total:Int){
 Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Ink).padding(18.dp)){
  Image(painterResource(com.daymark.app.R.drawable.ic_daymark_illustration), contentDescription="Ilustrasi Daymark", modifier=Modifier.fillMaxWidth().height(82.dp))
  Spacer(Modifier.height(10.dp))
  Text("HARI INI",color=Accent,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.6.sp);Spacer(Modifier.height(7.dp));Text("Pelan-pelan, yang penting jalan.",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(15.dp));Row(verticalAlignment=Alignment.Bottom){Text("$rate%",color=Color.White,fontSize=31.sp,fontWeight=FontWeight.Black);Spacer(Modifier.width(8.dp));Text("$done dari $total tugas selesai",color=Color(0xFFBFC3BE),fontSize=12.sp);}}}
@Composable private fun WaterCard(w:Int,plus:()->Unit,minus:()->Unit){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(18.dp)).padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).clip(CircleShape).background(Accent),contentAlignment=Alignment.Center){Text("💧",fontSize=20.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("Air putih",fontWeight=FontWeight.Bold);Text("$w / 8 gelas",color=Muted,fontSize=12.sp)};TextButton(onClick=minus){Text("−",fontSize=20.sp)};Button(onClick=plus,colors=ButtonDefaults.buttonColors(containerColor=Ink,contentColor=Accent)){Text("+1")}}}
@Composable private fun MealCard(done:Set<String>,toggle:(String)->Unit){val ms=listOf("Pagi","Siang","Sore","Malam");Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(18.dp)).padding(16.dp)){Text("Makan 4×",fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){ms.forEach{m->val ok=m in done;Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{toggle(m)}){Box(Modifier.size(38.dp).clip(CircleShape).background(if(ok)Accent else Paper),contentAlignment=Alignment.Center){Text(if(ok)"✓" else "○",fontWeight=FontWeight.Black)};Spacer(Modifier.height(4.dp));Text(m,fontSize=10.sp,color=Muted)}}}}}
@Composable private fun Habits(habits:List<Habit>,date:LocalDate,toggle:(Long)->Unit,add:()->Unit){LazyColumn(contentPadding=PaddingValues(22.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){item{Row{Text("${habits.size} habit",color=Muted,fontSize=13.sp);Spacer(Modifier.weight(1f));Small("+ habit",add)}};items(habits,key={it.id}){HabitRow(it,date,toggle)}}}
@Composable private fun Progress(tasks:List<Task>,habits:List<Habit>,water:Map<String,Int>,meals:Map<String,Set<String>>){
 val today=LocalDate.now();val ws=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));val days=(0..6).map{ws.plusDays(it.toLong())};val wt=tasks.filter{LocalDate.parse(it.date) in days};val tr=if(wt.isEmpty())0 else wt.count{it.done}*100/wt.size;val hc=habits.sumOf{h->days.count{it.toString() in h.dates}};val hp=if(habits.isEmpty())0 else hc*100/(habits.size*7);val glasses=days.sumOf{water[it.toString()]?:0};val mealsDone=days.sumOf{meals[it.toString()]?.size?:0}
 LazyColumn(contentPadding=PaddingValues(22.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){item{Section("MINGGU INI")};item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("TO-DO","$tr%");Stat("HABIT","$hp%")}};item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("AIR","$glasses");Stat("MAKAN","$mealsDone")}};item{Section("AKTIVITAS 7 HARI")};item{Bars(days,tasks,habits)};item{Section("STREAK")};items(habits,key={it.id}){h->val s=streak(h.dates);Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(17.dp)).padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).clip(CircleShape).background(if(s>0)Accent else Paper),contentAlignment=Alignment.Center){Text("$s",fontWeight=FontWeight.Black)};Spacer(Modifier.width(12.dp));Text(h.name,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Text("hari",color=Muted,fontSize=12.sp)}}}
}
@Composable private fun Bars(days:List<LocalDate>,tasks:List<Task>,habits:List<Habit>){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(18.dp)).padding(15.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.Bottom){days.forEach{d->val n=tasks.count{it.date==d.toString()&&it.done}+habits.count{d.toString() in it.dates};Column(horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.width(25.dp).height((18+n.coerceAtMost(8)*9).dp).clip(RoundedCornerShape(7.dp)).background(if(d==LocalDate.now())Ink else if(n>0)Accent else Line));Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT,Locale("id","ID")).take(2),fontSize=9.sp,color=Muted)}}}}
@Composable private fun More(name:String,dark:Boolean,edit:()->Unit,toggle:()->Unit,tutorial:()->Unit,export:()->Unit){LazyColumn(contentPadding=PaddingValues(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text(if(name.isBlank())"Belum ada nama" else name,fontSize=22.sp,fontWeight=FontWeight.Black);Text("Daymark berjalan offline di perangkatmu.",color=Muted,fontSize=12.sp)};item{Setting("👤","Nama","$name",edit)};item{Setting("🌙","Tema",if(dark)"Gelap" else "Terang",toggle)};item{Setting("📖","Tutorial","Lihat cara menggunakan Daymark",tutorial)};item{Setting("💾","Backup","Bagikan data sebagai teks",export)};item{Text("Privasi",fontWeight=FontWeight.Black);Text("Tidak ada akun, server, atau AI. Data disimpan lokal.",color=Muted,fontSize=12.sp)};item{Text("Daymark v2.0",color=Muted,fontSize=11.sp)} }}
@Composable private fun Setting(icon:String,title:String,body:String,click:()->Unit){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(17.dp)).clickable{click()}.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=21.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(body,color=Muted,fontSize=12.sp)};Icon(Icons.Default.ChevronRight,null,tint=Muted)}}
@Composable private fun TaskRow(t:Task,toggle:(Long)->Unit){Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(17.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Check(t.done){toggle(t.id)};Spacer(Modifier.width(12.dp));Column{Text(t.title,fontWeight=FontWeight.SemiBold,textDecoration=if(t.done)TextDecoration.LineThrough else TextDecoration.None,color=if(t.done)Muted else Ink);if(t.time.isNotBlank())Text(t.time,color=Muted,fontSize=11.sp)}}}
@Composable private fun HabitRow(h:Habit,d:LocalDate,toggle:(Long)->Unit){val ok=d.toString() in h.dates;val s=streakAs(d,h.dates);Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(17.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).clip(CircleShape).background(Paper),contentAlignment=Alignment.Center){Text(h.icon,fontSize=20.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(h.name,fontWeight=FontWeight.SemiBold);Text(if(s>0)"$s hari streak" else "Mulai hari ini",color=Muted,fontSize=11.sp)};Check(ok){toggle(h.id)} }}
@Composable private fun Check(ok:Boolean,on:()->Unit){Box(Modifier.size(28.dp).clip(CircleShape).background(if(ok)Accent else Paper).border(1.dp,Line,CircleShape).clickable{on()},contentAlignment=Alignment.Center){if(ok)Icon(Icons.Default.Check,null,modifier=Modifier.size(17.dp))}}
@Composable private fun DaySwitch(d:LocalDate,prev:()->Unit,next:()->Unit){Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.clip(RoundedCornerShape(12.dp)).border(1.dp,Line,RoundedCornerShape(12.dp))){Text("‹",Modifier.clickable{prev()}.padding(12.dp),fontSize=20.sp,color=Muted);Text(d.format(DateTimeFormatter.ofPattern("EEE, d MMM",Locale("id","ID"))),fontSize=12.sp,fontWeight=FontWeight.Bold);Text("›",Modifier.clickable{next()}.padding(12.dp),fontSize=20.sp,color=Muted)}}
@Composable private fun Nav(sel:Int,on:(Int)->Unit){Row(Modifier.fillMaxWidth().navigationBarsPadding().background(Card).padding(8.dp),horizontalArrangement=Arrangement.SpaceEvenly){listOf("Today" to Icons.Default.Today,"Habits" to Icons.Default.Repeat,"Progress" to Icons.Default.Insights,"Lainnya" to Icons.Default.MoreHoriz).forEachIndexed{i,(s,ic)->Column(Modifier.clickable{on(i)}.padding(7.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(ic,null,tint=if(i==sel)Ink else Muted,modifier=Modifier.size(20.dp));Text(s,fontSize=10.sp,color=if(i==sel)Ink else Muted,fontWeight=if(i==sel)FontWeight.Bold else FontWeight.Normal)}}}}
@Composable private fun Section(s:String){Text(s,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.6.sp,color=Muted)}
@Composable private fun Small(s:String,on:()->Unit){Text(s,Modifier.clip(RoundedCornerShape(10.dp)).background(Ink).clickable{on()}.padding(horizontal=12.dp,vertical=8.dp),color=Accent,fontSize=11.sp,fontWeight=FontWeight.Bold)}
@Composable private fun Empty(a:String,b:String){Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).border(1.dp,Line,RoundedCornerShape(17.dp)).padding(18.dp)){Text(a,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=12.sp)}}
@Composable private fun Stat(a:String,b:String){Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp,Line,RoundedCornerShape(18.dp)).padding(16.dp)){Text(a,fontSize=10.sp,fontWeight=FontWeight.Black,color=Muted);Spacer(Modifier.height(8.dp));Text(b,fontSize=27.sp,fontWeight=FontWeight.Black)}}

@Composable private fun TextDialog(title:String,hint:String,initial:String,onSave:(String)->Unit){var v by remember{mutableStateOf(initial)};AlertDialog(onDismissRequest={},title={Text(title,fontWeight=FontWeight.Black)},text={OutlinedTextField(v,{v=it},placeholder={Text(hint)},singleLine=true)},confirmButton={Button(onClick={if(v.isNotBlank())onSave(v.trim())},colors=ButtonDefaults.buttonColors(containerColor=Ink,contentColor=Accent)){Text("Simpan")}})}
@Composable private fun HabitDialog(onSave:(String,String)->Unit){var n by remember{mutableStateOf("")};var icon by remember{mutableStateOf("✓")};AlertDialog(onDismissRequest={},title={Text("Habit baru",fontWeight=FontWeight.Black)},text={Column{OutlinedTextField(n,{n=it},placeholder={Text("Nama habit")});Spacer(Modifier.height(10.dp));Text("Pilih icon");Row{listOf("💧","🍚","💻","💼","🚶","🧹").forEach{i->Text(i,Modifier.padding(7.dp).clickable{icon=i},fontSize=22.sp)}}}},confirmButton={Button(onClick={if(n.isNotBlank())onSave(n.trim(),icon)},colors=ButtonDefaults.buttonColors(containerColor=Ink,contentColor=Accent)){Text("Tambah")}})}
@Composable private fun Tutorial(close:()->Unit){var page by remember{mutableIntStateOf(0)};val titles=listOf("Selamat datang di Daymark","Atur hari tanpa ribet","Jaga makan & minum","Lihat progresmu");val bodies=listOf("Daymark adalah planner offline untuk membuat hari yang lebih terarah.","Di Today, tambahkan To-Do. Geser tanggal untuk melihat hari lain dan centang tugas yang selesai.","Gunakan Makan 4× dan counter Air Putih. Tekan +1 setiap kali minum; target dasar 8 gelas.","Habit dan Progress menyimpan check-in berdasarkan tanggal. Konsisten lebih penting daripada sempurna.");AlertDialog(onDismissRequest=close,title={Text(titles[page],fontWeight=FontWeight.Black)},text={Column{Box(Modifier.fillMaxWidth().height(95.dp).clip(RoundedCornerShape(18.dp)).background(if(page%2==0)Accent else Ink),contentAlignment=Alignment.Center){Text(listOf("☀","✓","💧","▥")[page],fontSize=42.sp)};Spacer(Modifier.height(14.dp));Text(bodies[page],color=Muted)}},confirmButton={Button(onClick={if(page<3)page++ else close()},colors=ButtonDefaults.buttonColors(containerColor=Ink,contentColor=Accent)){Text(if(page<3)"Lanjut" else "Mulai")}},dismissButton={if(page<3)TextButton(onClick=close){Text("Lewati")}})}
@Composable private fun BarsIcon():ImageVector=Icons.Default.BarChart

private fun streak(dates:Set<String>):Int=streakAs(LocalDate.now(),dates)
private fun streakAs(d:LocalDate,dates:Set<String>):Int{var c=d;var n=0;while(dates.contains(c.toString())){n++;c=c.minusDays(1)};return n}

private class Store(c:Context){
 private val context=c
 private val p=c.getSharedPreferences("daymark_v2",Context.MODE_PRIVATE)
 fun tasks():List<Task>{try{val a=JSONArray(p.getString("tasks","[]"));return List(a.length()){i->val o=a.getJSONObject(i);Task(o.getLong("id"),o.getString("date"),o.getString("title"),o.optString("time"),o.optBoolean("done"))}}catch(e:Exception){return defaultsTasks()}}
 fun habits():List<Habit>{try{val a=JSONArray(p.getString("habits","[]"));return List(a.length()){i->val o=a.getJSONObject(i);Habit(o.getLong("id"),o.getString("name"),o.optString("icon","✓"),buildSet{val x=o.optJSONArray("dates")?:JSONArray();for(j in 0 until x.length())add(x.getString(j))})}}catch(e:Exception){return defaultsHabits()}}
 fun water():Map<String,Int>{val o=JSONObject(p.getString("water","{}"));return buildMap{for(k in o.keys())put(k,o.getInt(k))}}
 fun meals():Map<String,Set<String>>{val o=JSONObject(p.getString("meals","{}"));return buildMap{for(k in o.keys()){val a=o.getJSONArray(k);put(k,buildSet{for(i in 0 until a.length())add(a.getString(i))})}}}
 fun name()=p.getString("name","");fun dark()=p.getBoolean("dark",false);fun seenTutorial()=p.getBoolean("tutorial",false)
 fun saveTasks(x:List<Task>){p.edit().putString("tasks",JSONArray().apply{x.forEach{put(JSONObject().apply{put("id",it.id);put("date",it.date);put("title",it.title);put("time",it.time);put("done",it.done)})}}.toString()).apply()}
 fun saveHabits(x:List<Habit>){p.edit().putString("habits",JSONArray().apply{x.forEach{put(JSONObject().apply{put("id",it.id);put("name",it.name);put("icon",it.icon);put("dates",JSONArray(it.dates.toList()))})}}.toString()).apply()}
 fun saveWater(x:Map<String,Int>){val o=JSONObject();x.forEach{(k,v)->o.put(k,v)};p.edit().putString("water",o.toString()).apply()}
 fun saveMeals(x:Map<String,Set<String>>){val o=JSONObject();x.forEach{(k,v)->o.put(k,JSONArray(v.toList()))};p.edit().putString("meals",o.toString()).apply()}
 fun saveName(x:String)=p.edit().putString("name",x).apply();fun saveDark(x:Boolean)=p.edit().putBoolean("dark",x).apply();fun setTutorial()=p.edit().putBoolean("tutorial",true).apply()
 fun export(t:List<Task>,h:List<Habit>,w:Map<String,Int>,m:Map<String,Set<String>>){val s="Daymark backup\nTasks: ${t.size}\nHabits: ${h.size}\nWater days: ${w.size}\nMeal days: ${m.size}";context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,s)},"Bagikan backup"))}
 private fun defaultsTasks()=listOf("Bangun & beresin tempat tidur","Makan 1 — pagi","Belajar coding 60 menit","Cari lowongan kerja","Makan 2 — siang","Belajar skill / CorelDRAW","Jalan santai 20–30 menit","Makan 3 — sore","Apply lowongan / rapihin CV","Makan 4 — malam","Review hari & rencana besok","Mulai tidur").mapIndexed{i,s->Task(System.currentTimeMillis()+i,LocalDate.now().toString(),s,"",false)}
 private fun defaultsHabits()=listOf("Makan 4× sehari" to "🍚","Minum air 8 gelas" to "💧","Belajar skill 60 menit" to "💻","Apply 3 lowongan" to "💼","Aktivitas fisik 20–30 menit" to "🚶","Beres-beres 1×" to "🧹").mapIndexed{i,(n,ic)->Habit(System.currentTimeMillis()+100+i,n,ic,emptySet())}
 fun saveAllDefaults(){if(!p.contains("tasks"))saveTasks(defaultsTasks());if(!p.contains("habits"))saveHabits(defaultsHabits())}
 init{saveAllDefaults()}
}
