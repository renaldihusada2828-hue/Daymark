# Daymark 2.2.0

Native Android planner + habit tracker, offline.

## Update 2.2
- Dark mode uses a dedicated dark palette instead of hard-coded light cards.
- Status bar and navigation bar icons follow the selected theme.
- Habit icons use a consistent flat Material icon system; no generated habit artwork.
- Launcher icon redesigned as a flat checklist + progress mark.
- Existing To-Do, habit targets, streaks, weekly progress, tutorial, settings, backup, profile, and reset remain available.
- Build target: Android API 35 / JDK 17 / Gradle 8.11.1.
