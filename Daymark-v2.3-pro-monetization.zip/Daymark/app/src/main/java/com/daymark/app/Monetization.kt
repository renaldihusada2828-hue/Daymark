
package com.daymark.app

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.LoadAdError

class DaymarkBilling(private val activity: Activity, private val unused: (Boolean) -> Unit = {}) {
    private var billingClient: BillingClient? = null
    private var monthly: ProductDetails? = null
    private var yearly: ProductDetails? = null
    private var onPro: (() -> Unit)? = null

    fun attach(onPro: () -> Unit) {
        this.onPro = onPro
        billingClient = BillingClient.newBuilder(activity)
            .setListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                    purchases.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }.forEach {
                        if (!it.isAcknowledged) {
                            billingClient?.acknowledgePurchase(
                                AcknowledgePurchaseParams.newBuilder().setPurchaseToken(it.purchaseToken).build()
                            ) {}
                        }
                        onPro()
                    }
                }
            }
            .enablePendingPurchases()
            .build()
        billingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProducts()
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun queryProducts() {
        val products = listOf(
            QueryProductDetailsParams.Product.newBuilder().setProductId("daymark_pro_monthly").setProductType(BillingClient.ProductType.SUBS).build(),
            QueryProductDetailsParams.Product.newBuilder().setProductId("daymark_pro_yearly").setProductType(BillingClient.ProductType.SUBS).build()
        )
        billingClient?.queryProductDetailsAsync(
            QueryProductDetailsParams.newBuilder().setProductList(products).build()
        ) { result, details ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                details.productDetailsList.forEach {
                    when (it.productId) {
                        "daymark_pro_monthly" -> monthly = it
                        "daymark_pro_yearly" -> yearly = it
                    }
                }
            }
        }
    }

    fun buyMonthly() = buy(monthly)
    fun buyYearly() = buy(yearly)

    private fun buy(product: ProductDetails?) {
        if (product == null) return
        val offer = product.subscriptionOfferDetails?.firstOrNull() ?: return
        val token = offer.offerToken
        val params = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(product)
            .setOfferToken(token)
            .build()
        billingClient?.launchBillingFlow(
            activity,
            BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(params)).build()
        )
    }
}

class DaymarkAds(private val context: Context) {
    companion object {
        // Google test IDs. Replace with your real AdMob IDs before Play Store release.
        const val BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
        const val INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    }

    private var interstitial: InterstitialAd? = null

    init {
        MobileAds.initialize(context)
        loadInterstitial()
    }

    private fun loadInterstitial() {
        InterstitialAd.load(context, INTERSTITIAL_ID, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
        })
    }

    fun showInterstitial() {
        val ad = interstitial ?: run { loadInterstitial(); return }
        if (context is Activity) {
            ad.show(context)
            interstitial = null
            loadInterstitial()
        }
    }
}
