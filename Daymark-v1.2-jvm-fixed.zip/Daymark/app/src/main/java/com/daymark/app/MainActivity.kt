package com.daymark.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private val Ink = Color(0xFF171A19)
private val Paper = Color(0xFFF5F4EF)
private val Card = Color(0xFFFFFEFA)
private val Muted = Color(0xFF737772)
private val Line = Color(0xFFE2E1DA)
private val Accent = Color(0xFFC9F36B)
private val AccentDark = Color(0xFF34410F)

private data class Task(val id: Long, val date: String, val title: String, val done: Boolean)
private data class Habit(val id: Long, val name: String, val doneDates: Set<String>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DaymarkApp(this) }
    }
}

@Composable
private fun DaymarkApp(context: Context) {
    val store = remember { LocalStore(context) }
    var tasks by remember { mutableStateOf(store.loadTasks()) }
    var habits by remember { mutableStateOf(store.loadHabits()) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var editingTask by remember { mutableStateOf<Task?>(null) }
    var deletingTask by remember { mutableStateOf<Task?>(null) }
    var editingHabit by remember { mutableStateOf<Habit?>(null) }
    var deletingHabit by remember { mutableStateOf<Habit?>(null) }
    var showAddTask by remember { mutableStateOf(false) }
    var showAddHabit by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    fun toggleTask(id: Long) {
        tasks = tasks.map { if (it.id == id && it.date == selectedDate.toString()) it.copy(done = !it.done) else it }
        store.saveTasks(tasks)
    }
    fun toggleHabit(id: Long, date: LocalDate = selectedDate) {
        val key = date.toString()
        habits = habits.map { h ->
            if (h.id != id) h else {
                val dates = h.doneDates.toMutableSet()
                if (!dates.add(key)) dates.remove(key)
                h.copy(doneDates = dates)
            }
        }
        store.saveHabits(habits)
    }

    MaterialTheme(colorScheme = lightColorScheme(background = Paper, surface = Card, primary = Ink)) {
        Surface(Modifier.fillMaxSize(), color = Paper) {
            Column(Modifier.fillMaxSize()) {
                Header(selectedDate, tab, onToday = { selectedDate = LocalDate.now(); tab = 0 })
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> TodayScreen(
                            date = selectedDate,
                            tasks = tasks.filter { it.date == selectedDate.toString() },
                            habits = habits,
                            onPreviousDay = { selectedDate = selectedDate.minusDays(1) },
                            onNextDay = { selectedDate = selectedDate.plusDays(1) },
                            onToggleTask = ::toggleTask,
                            onToggleHabit = { toggleHabit(it) },
                            onAddTask = { showAddTask = true },
                            onEditTask = { editingTask = it },
                            onDeleteTask = { deletingTask = it },
                            onEditHabit = { editingHabit = it },
                            onDeleteHabit = { deletingHabit = it }
                        )
                        1 -> HabitsScreen(
                            habits = habits,
                            selectedDate = selectedDate,
                            onToggle = { toggleHabit(it) },
                            onAdd = { showAddHabit = true },
                            onEdit = { editingHabit = it },
                            onDelete = { deletingHabit = it }
                        )
                        2 -> ProgressScreen(tasks, habits)
                        else -> MoreScreen(onReset = { showReset = true })
                    }
                }
                BottomBar(tab) { tab = it }
            }
        }
    }

    if (showAddTask) ItemDialog(
        title = "Tugas baru", hint = "Apa yang perlu diselesaikan?", confirm = "Tambah",
        onDismiss = { showAddTask = false }, onSave = { title ->
            tasks = tasks + Task(System.currentTimeMillis(), selectedDate.toString(), title, false)
            store.saveTasks(tasks); showAddTask = false
        }
    )
    editingTask?.let { task -> ItemDialog(
        title = "Edit tugas", hint = "Nama tugas", initial = task.title, confirm = "Simpan",
        onDismiss = { editingTask = null }, onSave = { title ->
            tasks = tasks.map { if (it.id == task.id) it.copy(title = title) else it }
            store.saveTasks(tasks); editingTask = null
        }
    ) }
    deletingTask?.let { task -> ConfirmDialog(
        title = "Hapus tugas?", body = "\"${task.title}\" akan dihapus.",
        onDismiss = { deletingTask = null }, onConfirm = {
            tasks = tasks.filterNot { it.id == task.id }; store.saveTasks(tasks); deletingTask = null
        }
    ) }
    if (showAddHabit) ItemDialog(
        title = "Habit baru", hint = "Contoh: baca 20 menit", confirm = "Tambah",
        onDismiss = { showAddHabit = false }, onSave = { name ->
            habits = habits + Habit(System.currentTimeMillis(), name, emptySet())
            store.saveHabits(habits); showAddHabit = false
        }
    )
    editingHabit?.let { habit -> ItemDialog(
        title = "Edit habit", hint = "Nama habit", initial = habit.name, confirm = "Simpan",
        onDismiss = { editingHabit = null }, onSave = { name ->
            habits = habits.map { if (it.id == habit.id) it.copy(name = name) else it }
            store.saveHabits(habits); editingHabit = null
        }
    ) }
    deletingHabit?.let { habit -> ConfirmDialog(
        title = "Hapus habit?", body = "Riwayat check-in \"${habit.name}\" juga akan dihapus.",
        onDismiss = { deletingHabit = null }, onConfirm = {
            habits = habits.filterNot { it.id == habit.id }; store.saveHabits(habits); deletingHabit = null
        }
    ) }
    if (showReset) ConfirmDialog(
        title = "Reset semua data?", body = "Semua tugas, habit, dan riwayat akan dihapus. Ini tidak bisa dibatalkan.",
        onDismiss = { showReset = false }, onConfirm = {
            tasks = emptyList(); habits = emptyList(); store.clear(); showReset = false
        }
    )
}

@Composable
private fun Header(date: LocalDate, tab: Int, onToday: () -> Unit) {
    Column(Modifier.padding(horizontal = 22.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DAYMARK", fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 2.2.sp)
            Spacer(Modifier.weight(1f))
            if (tab == 0 && date != LocalDate.now()) Text("Hari ini", modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onToday() }.background(Ink).padding(horizontal = 10.dp, vertical = 7.dp), color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        when (tab) {
            0 -> {
                Text(date.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("id", "ID")).replaceFirstChar { it.uppercase() }, fontSize = 29.sp, fontWeight = FontWeight.Black)
                Text(date.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("id", "ID"))), color = Muted, fontSize = 14.sp)
            }
            1 -> { Text("Habits", fontSize = 29.sp, fontWeight = FontWeight.Black); Text("Konsisten, bukan sempurna.", color = Muted, fontSize = 14.sp) }
            2 -> { Text("Progress", fontSize = 29.sp, fontWeight = FontWeight.Black); Text("Lihat pola, bukan sekadar angka.", color = Muted, fontSize = 14.sp) }
            else -> { Text("Lainnya", fontSize = 29.sp, fontWeight = FontWeight.Black); Text("Pengaturan sederhana.", color = Muted, fontSize = 14.sp) }
        }
    }
}

@Composable
private fun TodayScreen(
    date: LocalDate, tasks: List<Task>, habits: List<Habit>, onPreviousDay: () -> Unit, onNextDay: () -> Unit,
    onToggleTask: (Long) -> Unit, onToggleHabit: (Long) -> Unit, onAddTask: () -> Unit,
    onEditTask: (Task) -> Unit, onDeleteTask: (Task) -> Unit, onEditHabit: (Habit) -> Unit, onDeleteHabit: (Habit) -> Unit
) {
    val doneTasks = tasks.count { it.done }
    val percent = if (tasks.isEmpty()) 0 else doneTasks * 100 / tasks.size
    LazyColumn(contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                DaySwitch(date, onPreviousDay, onNextDay)
                Spacer(Modifier.weight(1f)); SmallAction("+ tugas", onAddTask)
            }
        }
        item { ProgressStrip(percent, "$doneTasks dari ${tasks.size} tugas selesai") }
        item { SectionLabel("TUGAS") }
        if (tasks.isEmpty()) item { EmptyCard("Belum ada tugas", "Tambahkan satu hal kecil untuk hari ini.") }
        items(tasks, key = { it.id }) { task -> TaskRow(task, onToggleTask, onEditTask, onDeleteTask) }
        item { SectionLabel("HABIT") }
        if (habits.isEmpty()) item { EmptyCard("Belum ada habit", "Buat rutinitas kecil yang bisa kamu ulang.") }
        items(habits, key = { it.id }) { habit -> HabitRow(habit, date, onToggleHabit, onEditHabit, onDeleteHabit) }
    }
}

@Composable
private fun DaySwitch(date: LocalDate, previous: () -> Unit, next: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clip(RoundedCornerShape(13.dp)).border(1.dp, Line, RoundedCornerShape(13.dp))) {
        Text("‹", modifier = Modifier.clickable { previous() }.padding(horizontal = 13.dp, vertical = 7.dp), fontSize = 22.sp, color = Muted)
        Text(date.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale("id", "ID"))), modifier = Modifier.padding(horizontal = 3.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("›", modifier = Modifier.clickable { next() }.padding(horizontal = 13.dp, vertical = 7.dp), fontSize = 22.sp, color = Muted)
    }
}

@Composable
private fun HabitsScreen(habits: List<Habit>, selectedDate: LocalDate, onToggle: (Long) -> Unit, onAdd: () -> Unit, onEdit: (Habit) -> Unit, onDelete: (Habit) -> Unit) {
    val todayKey = selectedDate.toString()
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("${habits.size} habit", color = Muted, fontSize = 13.sp); Spacer(Modifier.weight(1f)); SmallAction("+ habit", onAdd) } }
        if (habits.isEmpty()) item { EmptyCard("Mulai dari satu", "Habit yang kecil lebih mudah dipertahankan.") }
        items(habits, key = { it.id }) { HabitRow(it, selectedDate, onToggle, onEdit, onDelete) }
        if (habits.isNotEmpty()) {
            item { SectionLabel("7 HARI TERAKHIR") }
            item { HabitWeekOverview(habits, selectedDate) }
        }
    }
}

@Composable
private fun HabitWeekOverview(habits: List<Habit>, date: LocalDate) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp)) {
        habits.forEachIndexed { index, habit ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(habit.name, modifier = Modifier.width(112.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (6 downTo 0).forEach { offset ->
                        val d = date.minusDays(offset.toLong())
                        Box(Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(if (d.toString() in habit.doneDates) Accent else Line), contentAlignment = Alignment.Center) { if (d.toString() in habit.doneDates) Text("✓", fontSize = 10.sp, color = AccentDark, fontWeight = FontWeight.Black) }
                    }
                }
            }
            if (index != habits.lastIndex) Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun ProgressScreen(tasks: List<Task>, habits: List<Habit>) {
    val today = LocalDate.now()
    val weekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val week = (0..6).map { weekStart.plusDays(it.toLong()) }
    val weekTasks = tasks.filter { LocalDate.parse(it.date) in week }
    val completedWeekTasks = weekTasks.count { it.done }
    val taskRate = if (weekTasks.isEmpty()) 0 else completedWeekTasks * 100 / weekTasks.size
    val habitChecks = habits.sumOf { h -> week.count { it.toString() in h.doneDates } }
    val possible = habits.size * 7
    val habitRate = if (possible == 0) 0 else habitChecks * 100 / possible
    val best = habits.maxByOrNull { currentStreak(it.doneDates) }

    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text("MINGGU INI", fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp, color = Muted) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("TASK", "$taskRate%", Modifier.weight(1f)); StatCard("HABIT", "$habitRate%", Modifier.weight(1f))
            }
        }
        item { SectionLabel("AKTIVITAS HARIAN") }
        item { WeeklyBars(week, tasks, habits) }
        item { SectionLabel("STREAK SAAT INI") }
        if (habits.isEmpty()) item { EmptyCard("Belum ada streak", "Tambahkan habit lalu lakukan check-in.") }
        items(habits.sortedByDescending { currentStreak(it.doneDates) }, key = { it.id }) { habit ->
            val streak = currentStreak(habit.doneDates)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(if (streak > 0) Accent else Line), contentAlignment = Alignment.Center) { Text(streak.toString(), fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(12.dp)); Text(habit.name, fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Text(if (streak == 1) "hari" else "hari", color = Muted, fontSize = 12.sp)
            }
        }
        if (best != null) item { Text("Streak terpanjang: ${best.name} — ${longestStreak(best.doneDates)} hari", color = Muted, fontSize = 12.sp) }
    }
}

@Composable
private fun WeeklyBars(week: List<LocalDate>, tasks: List<Task>, habits: List<Habit>) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
        week.forEach { day ->
            val taskCount = tasks.count { it.date == day.toString() && it.done }
            val habitCount = habits.count { day.toString() in it.doneDates }
            val value = (taskCount + habitCount).coerceAtMost(8)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.width(25.dp).height((18 + value * 9).dp).clip(RoundedCornerShape(7.dp)).background(if (day == LocalDate.now()) Ink else if (value > 0) Accent else Line))
                Text(day.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("id", "ID")).take(2), fontSize = 9.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun MoreScreen(onReset: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SettingRow("Offline-first", "Data disimpan di perangkat")
        SettingRow("Privasi", "Tidak ada akun atau server")
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(16.dp)).clickable { onReset() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DeleteOutline, null, tint = Muted); Spacer(Modifier.width(12.dp)); Column { Text("Hapus semua data", fontWeight = FontWeight.Bold); Text("Reset tugas, habit, dan riwayat", color = Muted, fontSize = 12.sp) }
        }
        Spacer(Modifier.weight(1f)); Text("Daymark 1.1 • Native Android", color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun SettingRow(title: String, body: String) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column { Text(title, fontWeight = FontWeight.Bold); Text(body, color = Muted, fontSize = 12.sp) } } }

@Composable
private fun ProgressStrip(percent: Int, subtitle: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Ink).padding(17.dp)) {
        Row(verticalAlignment = Alignment.Bottom) { Text("HARI INI", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp); Spacer(Modifier.weight(1f)); Text("$percent", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black); Text("%", color = Color.White, modifier = Modifier.padding(bottom = 4.dp)) }
        Spacer(Modifier.height(8.dp)); Text(subtitle, color = Color(0xFFBFC3BE), fontSize = 11.sp)
        Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Accent, trackColor = Color(0xFF3A3E3C))
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: (Long) -> Unit, onEdit: (Task) -> Unit, onDelete: (Task) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(17.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        CheckCircle(task.done) { onToggle(task.id) }; Spacer(Modifier.width(12.dp)); Text(task.title, modifier = Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = if (task.done) Muted else Ink, textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None)
        Icon(Icons.Default.Edit, "Edit", modifier = Modifier.size(19.dp).clickable { onEdit(task) }, tint = Muted); Spacer(Modifier.width(12.dp)); Icon(Icons.Default.DeleteOutline, "Hapus", modifier = Modifier.size(19.dp).clickable { onDelete(task) }, tint = Muted)
    }
}

@Composable
private fun HabitRow(habit: Habit, date: LocalDate, onToggle: (Long) -> Unit, onEdit: (Habit) -> Unit, onDelete: (Habit) -> Unit) {
    val done = date.toString() in habit.doneDates
    val streak = streakAsOf(date, habit.doneDates)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(17.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(habit.name, fontWeight = FontWeight.SemiBold); Text(if (streak == 0) "Mulai streak" else "$streak hari streak", color = Muted, fontSize = 12.sp) }
        Icon(Icons.Default.Edit, "Edit", modifier = Modifier.size(18.dp).clickable { onEdit(habit) }, tint = Muted); Spacer(Modifier.width(11.dp)); Icon(Icons.Default.DeleteOutline, "Hapus", modifier = Modifier.size(18.dp).clickable { onDelete(habit) }, tint = Muted); Spacer(Modifier.width(12.dp))
        Box(Modifier.size(40.dp).clip(CircleShape).background(if (done) Accent else Paper).border(1.dp, if (done) Accent else Line, CircleShape).clickable { onToggle(habit.id) }, contentAlignment = Alignment.Center) { if (done) Icon(Icons.Default.Check, null, tint = Ink, modifier = Modifier.size(18.dp)) else Text("○", color = Muted, fontSize = 21.sp) }
    }
}

@Composable private fun CheckCircle(done: Boolean, onClick: () -> Unit) { Box(Modifier.size(27.dp).clip(CircleShape).background(if (done) Accent else Paper).border(1.dp, if (done) Accent else Line, CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) { if (done) Icon(Icons.Default.Check, null, tint = Ink, modifier = Modifier.size(16.dp)) } }
@Composable private fun SectionLabel(text: String) { Text(text, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp, color = Muted) }
@Composable private fun SmallAction(text: String, onClick: () -> Unit) { Text(text, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Ink).clickable { onClick() }.padding(horizontal = 13.dp, vertical = 9.dp), color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
@Composable private fun StatCard(label: String, value: String, modifier: Modifier) { Column(modifier.clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(16.dp)) { Text(label, fontSize = 10.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.Black, color = Muted); Spacer(Modifier.height(10.dp)); Text(value, fontSize = 28.sp, fontWeight = FontWeight.Black) } }
@Composable private fun EmptyCard(title: String, body: String) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).border(1.dp, Line, RoundedCornerShape(17.dp)).padding(18.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(3.dp)); Text(body, color = Muted, fontSize = 13.sp) } }

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    Surface(shadowElevation = 8.dp, color = Card) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            NavItem("Today", Icons.Default.Today, selected == 0) { onSelect(0) }
            NavItem("Habits", Icons.Default.Repeat, selected == 1) { onSelect(1) }
            NavItem("Progress", Icons.Default.Insights, selected == 2) { onSelect(2) }
            NavItem("Lainnya", Icons.Default.MoreHoriz, selected == 3) { onSelect(3) }
        }
    }
}

@Composable private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) { Column(Modifier.clip(RoundedCornerShape(13.dp)).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = if (selected) Ink else Muted, modifier = Modifier.size(20.dp)); Text(label, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, color = if (selected) Ink else Muted) } }

@Composable
private fun ItemDialog(title: String, hint: String, confirm: String, initial: String = "", onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember(title, initial) { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Card, title = { Text(title, fontWeight = FontWeight.Black) }, text = { OutlinedTextField(value, { value = it }, placeholder = { Text(hint) }, singleLine = true, shape = RoundedCornerShape(14.dp)) }, confirmButton = { Button(onClick = { if (value.isNotBlank()) onSave(value.trim()) }, enabled = value.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Accent)) { Text(confirm) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
private fun ConfirmDialog(title: String, body: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Card, icon = { Icon(Icons.Default.WarningAmber, null, tint = Muted) }, title = { Text(title, fontWeight = FontWeight.Black) }, text = { Text(body, color = Muted) }, confirmButton = { Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Accent)) { Text("Hapus") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

private fun streakAsOf(date: LocalDate, dates: Set<String>): Int {
    var cursor = date
    var count = 0
    while (dates.contains(cursor.toString())) { count++; cursor = cursor.minusDays(1) }
    return count
}

private fun currentStreak(dates: Set<String>): Int {
    var cursor = LocalDate.now()
    var count = 0
    while (dates.contains(cursor.toString())) { count++; cursor = cursor.minusDays(1) }
    return count
}

private fun longestStreak(dates: Set<String>): Int {
    if (dates.isEmpty()) return 0
    val sorted = dates.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
    var best = 1; var current = 1
    for (i in 1 until sorted.size) {
        if (sorted[i] == sorted[i - 1].plusDays(1)) { current++ } else current = 1
        best = maxOf(best, current)
    }
    return best
}

private class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("daymark", Context.MODE_PRIVATE)

    fun loadTasks(): List<Task> = try {
        val a = JSONArray(prefs.getString("tasks", "[]"))
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            // Migration from v1: old tasks did not have a date, so place them on the first launch day.
            Task(o.getLong("id"), o.optString("date", LocalDate.now().toString()), o.getString("title"), o.optBoolean("done", false))
        }
    } catch (_: Exception) { emptyList() }

    fun saveTasks(items: List<Task>) {
        val a = JSONArray(); items.forEach { t -> a.put(JSONObject().apply { put("id", t.id); put("date", t.date); put("title", t.title); put("done", t.done) }) }
        prefs.edit().putString("tasks", a.toString()).apply()
    }

    fun loadHabits(): List<Habit> = try {
        val a = JSONArray(prefs.getString("habits", "[]"))
        List(a.length()) { i ->
            val o = a.getJSONObject(i); val d = o.optJSONArray("dates") ?: JSONArray()
            Habit(o.getLong("id"), o.getString("name"), toDateSet(d))
        }
    } catch (_: Exception) { emptyList() }

    fun saveHabits(items: List<Habit>) {
        val a = JSONArray(); items.forEach { h -> a.put(JSONObject().apply { put("id", h.id); put("name", h.name); put("dates", JSONArray(h.doneDates.toList())) }) }
        prefs.edit().putString("habits", a.toString()).apply()
    }

    fun clear() { prefs.edit().clear().apply() }
    private fun toDateSet(a: JSONArray) = buildSet { for (i in 0 until a.length()) add(a.getString(i)) }
}
