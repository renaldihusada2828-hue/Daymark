# Daymark

Native Android productivity app for daily tasks, habit tracking, streaks, and weekly progress.

## What's included
- Date-based daily tasks: each task belongs to a specific day.
- Task completion, edit, and delete.
- Habit check-ins stored as real calendar dates.
- Current streak and longest streak calculations.
- Seven-day habit overview.
- Weekly task/habit completion metrics and activity bars.
- Offline-first local storage with SharedPreferences + JSON.
- Simple data reset screen.
- Native Kotlin + Jetpack Compose Material 3 UI.
- GitHub Actions debug APK build.

## Build on GitHub
1. Create a GitHub repository.
2. Upload the contents of this folder.
3. Push to `main`, or open Actions and run **Build APK** manually.
4. Download `daymark-debug-apk` from the workflow artifacts.

The workflow intentionally uses Gradle's setup action rather than requiring a checked-in Gradle wrapper, so the repository stays small and the build version is pinned in CI.

## Product direction
Daymark uses a restrained paper/ink/lime visual system. It avoids gradients, excessive cards, fake metrics, stock illustrations, and decorative AI-generated visuals.
