# Daymark v2.4.1

Native Android / Jetpack Compose, offline-first.

Updates:
- Reminder notification channel fixed so scheduled reminders use the same channel as the receiver.
- Timed new To-Do reminders default to ON (can be turned off).
- Settings dialog is vertically scrollable.
- Onboarding title/header colors follow light/dark theme.
- App version 2.4.1 / versionCode 10.
- Custom accent themes remain local/offline.

Build with GitHub Actions workflow in `.github/workflows/build.yml`.
