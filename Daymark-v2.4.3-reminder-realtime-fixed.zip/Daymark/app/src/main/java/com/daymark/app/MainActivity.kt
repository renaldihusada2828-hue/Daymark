package com.daymark.app

import android.app.Activity
import android.provider.Settings
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.app.ActivityCompat
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val Ink = Color(0xFF151815)
private val Paper = Color(0xFFF5F5F0)
private val Card = Color(0xFFFFFEFB)
private val Muted = Color(0xFF747871)
private val Line = Color(0xFFE0E2DA)
private val Accent = Color(0xFFBDEB63)
private val ThemePresets = listOf(
    "Lime" to 0xFFBDEB63.toInt(), "Blue" to 0xFF72A7FF.toInt(), "Purple" to 0xFFB58CFF.toInt(),
    "Pink" to 0xFFFF86B8.toInt(), "Red" to 0xFFFF7A72.toInt(), "Orange" to 0xFFFFAE63.toInt(),
    "Yellow" to 0xFFF2D45C.toInt(), "Cyan" to 0xFF59D6D0.toInt(), "Teal" to 0xFF5BC8A5.toInt(),
    "Indigo" to 0xFF8B91FF.toInt(), "Sky" to 0xFF72C9F4.toInt(), "Rose" to 0xFFF08BA7.toInt()
)

data class Task(
    val id: Long,
    val date: String,
    val title: String,
    val time: String,
    val done: Boolean,
    val priority: Int,
    val habitId: String? = null,
    val reminderEnabled: Boolean = false,
    val reminderTime: String = ""
)

data class Habit(
    val id: String,
    val name: String,
    val icon: String,
    val target: Int,
    val checks: Map<String, Int> = emptyMap(),
    val reminderEnabled: Boolean = false,
    val reminderTime: String = "09:00"
)

private fun todayString(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
private fun parseDate(s: String): Calendar = Calendar.getInstance().apply {
    time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)!!
}
private fun shiftDate(s: String, days: Int): String = parseDate(s).apply { add(Calendar.DAY_OF_YEAR, days) }.let {
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(it.time)
}
private fun prettyDate(s: String): String = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(parseDate(s).time)
private fun shortDate(s: String): String = SimpleDateFormat("EEE, d MMM", Locale("id", "ID")).format(parseDate(s).time)

private class Store(context: Context) {
    private val p = context.getSharedPreferences("daymark_v21", Context.MODE_PRIVATE)

    fun name() = p.getString("name", "Kamu") ?: "Kamu"
    fun theme() = p.getString("theme", "system") ?: "system"
    fun accent() = p.getString("accent", "#BDEB63") ?: "#BDEB63"
    fun tutorialSeen() = p.getBoolean("tutorial", false)

    fun tasks(): MutableList<Task> {
        return try {
            val a = JSONArray(p.getString("tasks", "[]"))
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                Task(o.getLong("id"), o.getString("date"), o.getString("title"), o.optString("time"), o.optBoolean("done"), o.optInt("priority", 0), o.optString("habitId").takeIf { it.isNotBlank() }, o.optBoolean("reminderEnabled", false), o.optString("reminderTime"))
            }
        } catch (_: Exception) { mutableListOf() }
    }

    fun habits(): MutableList<Habit> {
        return try {
            val a = JSONArray(p.getString("habits", "[]"))
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                val c = o.optJSONObject("checks") ?: JSONObject()
                val map = mutableMapOf<String, Int>()
                c.keys().forEach { k -> map[k] = c.optInt(k, 0) }
                Habit(o.getString("id"), o.getString("name"), o.optString("icon", "other"), o.optInt("target", 1), map, o.optBoolean("reminderEnabled", false), o.optString("reminderTime", "09:00"))
            }
        } catch (_: Exception) { mutableListOf() }
    }

    fun water(): MutableMap<String, Int> {
        val o = try { JSONObject(p.getString("water", "{}")) } catch (_: Exception) { JSONObject() }
        return mutableMapOf<String, Int>().also { out -> o.keys().forEach { out[it] = o.optInt(it) } }
    }

    fun meals(): MutableMap<String, MutableSet<String>> {
        val o = try { JSONObject(p.getString("meals", "{}")) } catch (_: Exception) { JSONObject() }
        return mutableMapOf<String, MutableSet<String>>().also { out ->
            o.keys().forEach { day ->
                val a = o.optJSONArray(day) ?: JSONArray()
                out[day] = mutableSetOf<String>().also { set -> for (i in 0 until a.length()) set.add(a.getString(i)) }
            }
        }
    }

    fun seededDates(): MutableSet<String> {
        val a = try { JSONArray(p.getString("seeded", "[]")) } catch (_: Exception) { JSONArray() }
        return mutableSetOf<String>().also { set -> for (i in 0 until a.length()) set.add(a.getString(i)) }
    }

    fun saveTasks(list: List<Task>) {
        val a = JSONArray()
        list.forEach { t -> a.put(JSONObject().apply {
            put("id", t.id); put("date", t.date); put("title", t.title); put("time", t.time); put("done", t.done); put("priority", t.priority); put("habitId", t.habitId ?: ""); put("reminderEnabled", t.reminderEnabled); put("reminderTime", t.reminderTime)
        }) }
        p.edit().putString("tasks", a.toString()).apply()
    }

    fun saveHabits(list: List<Habit>) {
        val a = JSONArray()
        list.forEach { h -> a.put(JSONObject().apply {
            put("id", h.id); put("name", h.name); put("icon", h.icon); put("target", h.target); put("reminderEnabled", h.reminderEnabled); put("reminderTime", h.reminderTime)
            put("checks", JSONObject().apply { h.checks.forEach { (d, c) -> put(d, c) } })
        }) }
        p.edit().putString("habits", a.toString()).apply()
    }

    fun saveWater(map: Map<String, Int>) {
        p.edit().putString("water", JSONObject().apply { map.forEach { (d, n) -> put(d, n) } }.toString()).apply()
    }

    fun saveMeals(map: Map<String, Set<String>>) {
        p.edit().putString("meals", JSONObject().apply { map.forEach { (d, meals) -> put(d, JSONArray(meals.toList())) } }.toString()).apply()
    }

    fun saveSeeded(set: Set<String>) { p.edit().putString("seeded", JSONArray(set.toList()).toString()).apply() }
    fun saveName(v: String) { p.edit().putString("name", v).apply() }
    fun saveTheme(v: String) { p.edit().putString("theme", v).apply() }
    fun saveAccent(v: String) { p.edit().putString("accent", v).apply() }
    fun finishTutorial() { p.edit().putBoolean("tutorial", true).apply() }
    fun reset() { p.edit().clear().apply() }

    fun exportText(): String = JSONObject().apply {
        put("app", "Daymark"); put("version", "2.4.2")
        put("name", name()); put("theme", theme()); put("accent", accent())
        put("tasks", JSONArray(p.getString("tasks", "[]")))
        put("habits", JSONArray(p.getString("habits", "[]")))
        put("water", JSONObject(p.getString("water", "{}")))
        put("meals", JSONObject(p.getString("meals", "{}")))
    }.toString(2)
}

class DaymarkViewModel(private val app: Context) : ViewModel() {
    private val store = Store(app)
    var name by mutableStateOf(store.name()); private set
    var theme by mutableStateOf(store.theme()); private set
    var accentHex by mutableStateOf(store.accent()); private set
    var selectedDate by mutableStateOf(todayString()); private set
    var tasks by mutableStateOf<List<Task>>(emptyList()); private set
    var habits by mutableStateOf<List<Habit>>(emptyList()); private set
    var water by mutableStateOf<Map<String, Int>>(emptyMap()); private set
    var meals by mutableStateOf<Map<String, Set<String>>>(emptyMap()); private set

    init { ensureHabits(); ensureDay(selectedDate); reload(); ReminderScheduler.rescheduleAll(app) }

    private fun ensureHabits() {
        if (store.habits().isNotEmpty()) return
        store.saveHabits(listOf(
            Habit("meal4", "Makan 4× sehari", "meal", 4),
            Habit("study", "Belajar skill 60 menit", "study", 1),
            Habit("job", "Apply 3 lowongan", "work", 3),
            Habit("move", "Gerak 20–30 menit", "exercise", 1),
            Habit("clean", "Beres-beres 1×", "home", 1)
        ))
    }

    private fun defaults(date: String): List<Task> {
        val base = System.currentTimeMillis()
        return listOf(
            Task(base + 1, date, "Bangun & beresin tempat tidur", "07:30", false, 1, "clean"),
            Task(base + 2, date, "Makan 1 — sarapan", "08:00", false, 1, "meal4"),
            Task(base + 3, date, "Belajar coding 60 menit", "09:00", false, 1, "study"),
            Task(base + 4, date, "Cari lowongan kerja", "10:30", false, 2, "job"),
            Task(base + 5, date, "Makan 2 — siang", "12:30", false, 1, "meal4"),
            Task(base + 6, date, "Belajar skill / latihan", "14:30", "".isNotBlank(), 0, null),
            Task(base + 7, date, "Jalan santai / gerak 20–30 menit", "16:30", false, 0, "move"),
            Task(base + 8, date, "Makan 3 — sore", "18:00", false, 1, "meal4"),
            Task(base + 9, date, "Apply lowongan / rapihin CV", "19:00", false, 2, "job"),
            Task(base + 10, date, "Follow-up / apply 1 lagi", "20:00", false, 1, "job"),
            Task(base + 11, date, "Makan 4 — malam", "21:30", false, 1, "meal4"),
            Task(base + 12, date, "Review hari & rencana besok", "22:30", false, 0, null),
            Task(base + 13, date, "Mulai tidur", "23:30", false, 0, null)
        )
    }

    fun ensureDay(date: String) {
        val seeded = store.seededDates()
        if (date in seeded) return
        val all = store.tasks()
        store.saveTasks(all + defaults(date))
        seeded.add(date); store.saveSeeded(seeded)
    }

    fun reload() {
        tasks = store.tasks().filter { it.date == selectedDate }.sortedWith(compareBy({ it.time.isBlank() }, { it.time }, { it.id }))
        habits = store.habits()
        water = store.water()
        meals = store.meals()
    }

    fun moveDay(delta: Int) { selectedDate = shiftDate(selectedDate, delta); ensureDay(selectedDate); reload() }
    fun tasksForDates(dates: Set<String>): List<Task> = store.tasks().filter { it.date in dates }
    fun today() { selectedDate = todayString(); ensureDay(selectedDate); reload() }

    private fun adjustLinkedHabit(allHabits: MutableList<Habit>, habitId: String, date: String, delta: Int) {
        val i = allHabits.indexOfFirst { it.id == habitId }; if (i < 0) return
        val h = allHabits[i]; val current = h.checks[date] ?: 0
        val next = (current + delta).coerceIn(0, h.target)
        val map = h.checks.toMutableMap(); if (next == 0) map.remove(date) else map[date] = next
        allHabits[i] = h.copy(checks = map)
    }

    fun toggleTask(id: Long) {
        val all = store.tasks(); val i = all.indexOfFirst { it.id == id }; if (i < 0) return
        val old = all[i]; val now = !old.done; all[i] = old.copy(done = now)
        val linkedHabitId = old.habitId
        if (linkedHabitId != null) {
            val hs = store.habits()
            adjustLinkedHabit(hs, linkedHabitId, old.date, if (now) 1 else -1)
            store.saveHabits(hs)
        }
        store.saveTasks(all); reload()
    }

    fun addTask(title: String, time: String, priority: Int, reminder: Boolean, reminderTime: String) {
        val task = Task(System.currentTimeMillis(), selectedDate, title, time, false, priority, null, reminder, reminderTime)
        val all = store.tasks(); all.add(task); store.saveTasks(all); ReminderScheduler.scheduleTask(app, task); reload()
    }

    fun updateTask(task: Task, title: String, time: String, priority: Int, reminder: Boolean, reminderTime: String) {
        val all = store.tasks(); val i = all.indexOfFirst { it.id == task.id }; if (i >= 0) { val updated = task.copy(title = title, time = time, priority = priority, reminderEnabled = reminder, reminderTime = reminderTime); all[i] = updated; store.saveTasks(all); ReminderScheduler.cancelTask(app, task.id); ReminderScheduler.scheduleTask(app, updated) }; reload()
    }

    fun deleteTask(id: Long) {
        val all = store.tasks()
        val task = all.firstOrNull { it.id == id }
        val linkedHabitId = task?.habitId
        if (task?.done == true && linkedHabitId != null) {
            val hs = store.habits()
            adjustLinkedHabit(hs, linkedHabitId, task.date, -1)
            store.saveHabits(hs)
        }
        ReminderScheduler.cancelTask(app, id)
        store.saveTasks(all.filterNot { it.id == id })
        reload()
    }

    fun adjustHabit(id: String, delta: Int) {
        val hs = store.habits(); val i = hs.indexOfFirst { it.id == id }; if (i < 0) return
        val h = hs[i]; val current = h.checks[selectedDate] ?: 0; val next = (current + delta).coerceIn(0, h.target)
        val map = h.checks.toMutableMap(); if (next == 0) map.remove(selectedDate) else map[selectedDate] = next
        hs[i] = h.copy(checks = map); store.saveHabits(hs); reload()
    }

    fun saveHabit(id: String?, name: String, target: Int, icon: String, reminder: Boolean, reminderTime: String) {
        val hs = store.habits().toMutableList()
        if (id == null) { val h = Habit("h_" + System.currentTimeMillis(), name, icon, target.coerceIn(1, 20), emptyMap(), reminder, reminderTime); hs.add(h); ReminderScheduler.scheduleHabit(app, h) }
        else { val i = hs.indexOfFirst { it.id == id }; if (i >= 0) { val h = hs[i].copy(name = name, target = target.coerceIn(1, 20), icon = icon, reminderEnabled = reminder, reminderTime = reminderTime); hs[i] = h; ReminderScheduler.cancelHabit(app, h.id); ReminderScheduler.scheduleHabit(app, h) } }
        store.saveHabits(hs); reload()
    }

    fun deleteHabit(id: String) {
        ReminderScheduler.cancelHabit(app, id)
        store.saveHabits(store.habits().filterNot { it.id == id })
        store.saveTasks(store.tasks().map { if (it.habitId == id) it.copy(habitId = null) else it })
        reload()
    }

    fun updateName(v: String) { name = v.ifBlank { "Kamu" }; store.saveName(name) }
    fun updateTheme(v: String) { theme = v; store.saveTheme(v) }
    fun updateAccent(v: String) { accentHex = v; store.saveAccent(v) }
    fun finishTutorial() { store.finishTutorial() }
    fun tutorialSeen() = store.tutorialSeen()
    fun exportText() = store.exportText()
    fun reset() { store.reset(); name = "Kamu"; theme = "system"; accentHex = "#BDEB63"; selectedDate = todayString(); ensureHabits(); ensureDay(selectedDate); ReminderScheduler.rescheduleAll(app); reload() }
}

private class VMFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = DaymarkViewModel(context.applicationContext) as T
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.ensureChannel(this)
        setContent {
            val vm: DaymarkViewModel = viewModel(factory = VMFactory(this))
            DaymarkTheme(vm.theme, vm.accentHex) { DaymarkApp(vm) }
        }
        window.decorView.post { requestNotificationPermission() }
    }

    override fun onResume() {
        super.onResume()
        ReminderScheduler.rescheduleAll(this)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 1001)
        }
    }

    fun requestNotificationPermissionFromUi() { requestNotificationPermission() }
}

@Composable private fun DaymarkTheme(mode: String, accentHex: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> androidx.compose.foundation.isSystemInDarkTheme() }
    val accent = runCatching { Color(android.graphics.Color.parseColor(accentHex)) }.getOrDefault(Accent)
    val accentOn = if (accent.luminance() > 0.58f) Color(0xFF10120F) else Color.White
    val colors = if (dark) darkColorScheme(
        primary = accent, onPrimary = accentOn,
        secondary = accent, onSecondary = accentOn,
        background = Color(0xFF10120F), surface = Color(0xFF191C18),
        surfaceVariant = Color(0xFF242823), onSurface = Color(0xFFF3F5EF),
        onSurfaceVariant = Color(0xFFB9BEB6), outlineVariant = Color(0xFF3A4038)
    ) else lightColorScheme(
        primary = accent, onPrimary = accentOn,
        secondary = accent, onSecondary = accentOn,
        background = Paper, surface = Card, surfaceVariant = Color(0xFFECEDE7),
        onSurface = Ink, onSurfaceVariant = Muted, outlineVariant = Line
    )
    MaterialTheme(colorScheme = colors) {
        val view = LocalView.current
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
        content()
    }
}

enum class Screen { HOME, HABITS, PROGRESS, MORE }

@Composable private fun DaymarkApp(vm: DaymarkViewModel) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var showTutorial by remember { mutableStateOf(!vm.tutorialSeen()) }
    var taskDialog by remember { mutableStateOf<Task?>(null) }
    var showNewTask by remember { mutableStateOf(false) }
    var showNewHabit by remember { mutableStateOf(false) }
    var habitDialog by remember { mutableStateOf<Habit?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    if (showTutorial) {
        TutorialScreen { vm.finishTutorial(); showTutorial = false }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (screen == Screen.HOME || screen == Screen.HABITS) {
                FloatingActionButton(onClick = { if (screen == Screen.HOME) showNewTask = true else showNewHabit = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
                    Icon(Icons.Default.Add, "Tambah")
                }
            }
        },
        bottomBar = { BottomNav(screen) { screen = it } }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Header(vm.selectedDate, screen, vm::today)
            when (screen) {
                Screen.HOME -> HomeScreen(vm, { taskDialog = it }, { showNewTask = true }, { showNewHabit = true })
                Screen.HABITS -> HabitsScreen(vm, { habitDialog = it }, { showNewHabit = true })
                Screen.PROGRESS -> ProgressScreen(vm)
                Screen.MORE -> MoreScreen(
                    vm = vm,
                    onProfile = { showProfile = true },
                    onSettings = { showSettings = true },
                    onBackup = { showBackup = true },
                    onTutorial = { showTutorial = true },
                    onAbout = { showAbout = true },
                    onReset = { showReset = true }
                )
            }
        }
    }

    if (showNewTask) TaskEditor(null, vm.selectedDate, { t, time, p, r, rt -> vm.addTask(t, time, p, r, rt); showNewTask = false }, { showNewTask = false }, {})
    taskDialog?.let { task -> TaskEditor(task, vm.selectedDate, { t, time, p, r, rt -> vm.updateTask(task, t, time, p, r, rt); taskDialog = null }, { vm.deleteTask(task.id); taskDialog = null }, { taskDialog = null }) }
    if (showNewHabit) HabitEditor(null, { n, target, icon, r, rt -> vm.saveHabit(null, n, target, icon, r, rt); showNewHabit = false }, {}, { showNewHabit = false })
    habitDialog?.let { h -> HabitEditor(h, { n, target, icon, r, rt -> vm.saveHabit(h.id, n, target, icon, r, rt); habitDialog = null }, { vm.deleteHabit(h.id); habitDialog = null }, { habitDialog = null }) }
    if (habitDialog == null && screen == Screen.HABITS) { /* FAB intentionally opens new editor below */ }
    if (showSettings) SettingsDialog(vm, { showSettings = false })
    if (showProfile) ProfileDialog(vm) { showProfile = false }
    if (showBackup) BackupDialog(vm.exportText()) { showBackup = false }
    if (showAbout) AboutDialog { showAbout = false }
    if (showReset) ConfirmReset({ vm.reset(); showReset = false }, { showReset = false })
}

@Composable private fun Header(date: String, screen: Screen, today: () -> Unit) {
    Column(Modifier.padding(horizontal = 22.dp, vertical = 15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("DAYMARK", fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.weight(1f))
            if (date != todayString()) SmallButton("Hari ini", today)
        }
        Spacer(Modifier.height(12.dp))
        Text(when (screen) { Screen.HOME -> "Hari ini"; Screen.HABITS -> "Habits"; Screen.PROGRESS -> "Progress"; Screen.MORE -> "Lainnya" }, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text(if (screen == Screen.HOME) prettyDate(date) else when (screen) { Screen.HABITS -> "Konsisten, bukan sempurna."; Screen.PROGRESS -> "Lihat pola, bukan sekadar angka."; else -> "Atur Daymark sesuai caramu." }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
    }
}

@Composable private fun HomeScreen(vm: DaymarkViewModel, editTask: (Task) -> Unit, addTask: () -> Unit, addHabit: () -> Unit) {
    val tasks = vm.tasks; val done = tasks.count { it.done }; val rate = if (tasks.isEmpty()) 0 else done * 100 / tasks.size
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { DaySwitch(vm.selectedDate, { vm.moveDay(-1) }, { vm.moveDay(1) }); Spacer(Modifier.weight(1f)); SmallButton("+ tugas", addTask) } }
        item { ProgressCard(rate, done, tasks.size) }
        item { Section("TO-DO HARI INI") }
        if (tasks.isEmpty()) item { EmptyCard("Hari masih kosong", "Tambahkan satu tugas kecil untuk mulai.") }
        items(tasks, key = { it.id }) { TaskRow(it, { vm.toggleTask(it.id) }, { editTask(it) }) }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Section("HABIT"); Spacer(Modifier.weight(1f)); SmallButton("+ habit", addHabit) } }
        items(vm.habits.take(5), key = { it.id }) { HabitRow(it, vm.selectedDate, vm::adjustHabit) }
    }
}

@Composable private fun HabitsScreen(vm: DaymarkViewModel, edit: (Habit) -> Unit, add: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("${vm.habits.size} habit", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp); Spacer(Modifier.weight(1f)); SmallButton("+ habit", add) } }
        items(vm.habits, key = { it.id }) { h -> HabitRow(h, vm.selectedDate, vm::adjustHabit, onEdit = { edit(h) }) }
    }
}

@Composable private fun ProgressScreen(vm: DaymarkViewModel) {
    val days = (6 downTo 0).map { shiftDate(vm.selectedDate, -it) }
    val weekTasks = vmTasksForWeek(vm, days); val taskRate = if (weekTasks.isEmpty()) 0 else weekTasks.count { it.done } * 100 / weekTasks.size
    val possible = vm.habits.sumOf { it.target * 7 }; val actual = vm.habits.sumOf { h -> days.sumOf { d -> (h.checks[d] ?: 0).coerceAtMost(h.target) } }
    val habitRate = if (possible == 0) 0 else actual * 100 / possible
    val longest = vm.habits.maxOfOrNull { longestStreak(it) } ?: 0
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Section("MINGGU INI") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("To-Do", "$taskRate%", Modifier.weight(1f)); StatCard("Habit", "$habitRate%", Modifier.weight(1f)) } }
        item { StatCard("Streak terbaik", "$longest hari") }
        item { ChartCard(weekTasks, days) }
        item { InfoCard("Tentang angka", "Progress To-Do dihitung dari tugas minggu berjalan. Habit dihitung dari target harian masing-masing, jadi habit 4× benar-benar punya target 4.") }
    }
}

private fun vmTasksForWeek(vm: DaymarkViewModel, days: List<String>): List<Task> = vm.tasksForDates(days.toSet())

@Composable private fun MoreScreen(vm: DaymarkViewModel, onProfile: () -> Unit, onSettings: () -> Unit, onBackup: () -> Unit, onTutorial: () -> Unit, onAbout: () -> Unit, onReset: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ProfileCard(vm.name, onProfile) }
        item { Section("PENGATURAN") }
        item { SettingRow(Icons.Default.Settings, "Pengaturan", "Tema dan preferensi", onSettings) }
        item { SettingRow(Icons.Default.Backup, "Data & Backup", "Bagikan salinan data", onBackup) }
        item { SettingRow(Icons.Default.HelpOutline, "Cara pakai", "Buka tutorial lagi", onTutorial) }
        item { SettingRow(Icons.Default.Info, "Tentang Daymark", "Versi 2.4.2", onAbout) }
        item { SettingRow(Icons.Default.DeleteOutline, "Reset data", "Kembalikan data ke awal", onReset) }
    }
}

@Composable private fun ProgressCard(rate: Int, done: Int, total: Int) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surfaceContainerHighest).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("PROGRESS HARI INI", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(7.dp)); Text("Pelan-pelan, yang penting jalan.", color = MaterialTheme.colorScheme.onSurface, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp)); Text("$done dari $total tugas selesai", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        Box(contentAlignment = Alignment.Center) { CircularProgressIndicator(progress = { rate / 100f }, modifier = Modifier.size(72.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.outlineVariant, strokeWidth = 7.dp); Text("$rate%", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Black, fontSize = 15.sp) }
    }
}

@Composable private fun TaskRow(t: Task, toggle: () -> Unit, edit: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(17.dp)).clickable { edit() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        CheckCircleButton(t.done, toggle); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None, color = if (t.done) Muted else MaterialTheme.colorScheme.onSurface)
            if (t.time.isNotBlank()) Text(t.time, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
        if (t.priority > 0) Box(Modifier.size(7.dp).clip(CircleShape).background(if (t.priority == 2) Color(0xFFEF806B) else MaterialTheme.colorScheme.primary))
    }
}

@Composable private fun HabitRow(h: Habit, date: String, adjust: (String, Int) -> Unit, onEdit: (() -> Unit)? = null) {
    val count = (h.checks[date] ?: 0).coerceAtMost(h.target); val streak = streakAt(h, date)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp)).clickable(enabled = onEdit != null) { onEdit?.invoke() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        HabitIcon(h.icon, 48); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
            Text(h.name, fontWeight = FontWeight.Bold); Text(if (streak > 0) "$streak hari streak" else "$count/${h.target} hari ini", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            Spacer(Modifier.height(7.dp)); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { (6 downTo 0).forEach { off -> val d = shiftDate(date, -off); val c = (h.checks[d] ?: 0).coerceAtMost(h.target); Box(Modifier.size(8.dp).clip(CircleShape).background(if (c >= h.target) MaterialTheme.colorScheme.primary else if (c > 0) MaterialTheme.colorScheme.primary.copy(alpha = .45f) else MaterialTheme.colorScheme.outlineVariant)) } }
        }
        IconButton(onClick = { adjust(h.id, -1) }, enabled = count > 0) { Icon(Icons.Default.Remove, "Kurangi", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        Text("$count", fontWeight = FontWeight.Black, modifier = Modifier.widthIn(min = 20.dp))
        IconButton(onClick = { adjust(h.id, 1) }, enabled = count < h.target) { Icon(Icons.Default.Add, "Tambah") }
    }
}

@Composable private fun HabitIcon(key: String, size: Int) {
    val icon = when (key) {
        "water" -> Icons.Default.WaterDrop
        "meal" -> Icons.Default.Restaurant
        "exercise", "fitness" -> Icons.Default.FitnessCenter
        "study" -> Icons.Default.School
        "work" -> Icons.Default.Work
        "nosmoke" -> Icons.Default.Block
        "sleep" -> Icons.Default.Bedtime
        "health" -> Icons.Default.Favorite
        "mental", "meditate" -> Icons.Default.SelfImprovement
        "target" -> Icons.Default.TrackChanges
        "finance" -> Icons.Default.AccountBalanceWallet
        "growth" -> Icons.Default.TrendingUp
        "journal" -> Icons.Default.EditNote
        "social" -> Icons.Default.People
        "hobby" -> Icons.Default.SportsEsports
        "home", "clean" -> Icons.Default.Home
        "creative" -> Icons.Default.Brush
        else -> Icons.Default.CheckCircle
    }
    Box(
        modifier = Modifier.size(size.dp).clip(RoundedCornerShape(size / 3f)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size((size * .52f).dp), tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable private fun TaskEditor(task: Task?, date: String, save: (String, String, Int, Boolean, String) -> Unit, delete: () -> Unit, close: () -> Unit) {
    var title by remember(task?.id) { mutableStateOf(task?.title ?: "") }
    var time by remember(task?.id) { mutableStateOf(task?.time ?: "") }
    var priority by remember(task?.id) { mutableIntStateOf(task?.priority ?: 0) }
    var reminder by remember(task?.id) { mutableStateOf(task?.reminderEnabled ?: (task?.time?.isNotBlank() == true)) }
    var reminderTime by remember(task?.id) { mutableStateOf(task?.reminderTime?.ifBlank { task?.time ?: "09:00" } ?: (task?.time ?: "09:00")) }
    AlertDialog(onDismissRequest = close, title = { Text(if (task == null) "Tambah To-Do" else "Edit To-Do", fontWeight = FontWeight.Black) }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(title, { title = it }, label = { Text("Tugas") }, singleLine = true)
        OutlinedTextField(time, { time = it }, label = { Text("Jam, contoh 09:00") }, singleLine = true)
        Text("Prioritas", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf(0 to "Biasa", 1 to "Penting", 2 to "Urgent").forEach { (v, s) -> FilterChip(selected = priority == v, onClick = { priority = v }, label = { Text(s) }) } }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Pengingat", Modifier.weight(1f), fontWeight = FontWeight.Bold); Switch(reminder, { reminder = it }) }
        if (reminder) OutlinedTextField(reminderTime, { reminderTime = it }, label = { Text("Jam pengingat, contoh 09:00") }, singleLine = true)
    } }, confirmButton = { Button(enabled = title.isNotBlank(), onClick = { save(title.trim(), time.trim(), priority, reminder, reminderTime.trim()) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) { Text("Simpan") } }, dismissButton = { if (task != null) TextButton(onClick = delete) { Text("Hapus") } else TextButton(onClick = delete) { Text("Batal") } })
}

private val iconChoices = listOf("water", "meal", "exercise", "study", "work", "nosmoke", "sleep", "health", "meditate", "target", "finance", "growth", "journal", "social", "hobby", "home", "fitness", "creative", "other")

@Composable private fun HabitEditor(habit: Habit?, save: (String, Int, String, Boolean, String) -> Unit, delete: () -> Unit, cancel: () -> Unit) {
    var name by remember(habit?.id) { mutableStateOf(habit?.name ?: "") }; var target by remember(habit?.id) { mutableIntStateOf(habit?.target ?: 1) }; var icon by remember(habit?.id) { mutableStateOf(habit?.icon ?: "other") }
    var reminder by remember(habit?.id) { mutableStateOf(habit?.reminderEnabled ?: false) }; var reminderTime by remember(habit?.id) { mutableStateOf(habit?.reminderTime ?: "09:00") }
    AlertDialog(onDismissRequest = cancel, title = { Text(if (habit == null) "Habit baru" else "Edit habit", fontWeight = FontWeight.Black) }, text = { Column(Modifier.heightIn(max = 500.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("Nama habit") }, singleLine = true)
        Text("Target per hari: $target×", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { target = (target - 1).coerceAtLeast(1) }) { Icon(Icons.Default.Remove, null) }; Slider(target.toFloat(), { target = it.toInt().coerceIn(1, 20) }, valueRange = 1f..20f, steps = 18, modifier = Modifier.weight(1f)); IconButton(onClick = { target = (target + 1).coerceAtMost(20) }) { Icon(Icons.Default.Add, null) } }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Pengingat harian", Modifier.weight(1f), fontWeight = FontWeight.Bold); Switch(reminder, { reminder = it }) }
        if (reminder) OutlinedTextField(reminderTime, { reminderTime = it }, label = { Text("Jam, contoh 09:00") }, singleLine = true)
        Text("Pilih ikon", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) { iconChoices.take(6).forEach { k -> Box(Modifier.size(48.dp).clickable { icon = k }.border(if (icon == k) 2.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp))) { HabitIcon(k, 46) } } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) { iconChoices.drop(6).take(6).forEach { k -> Box(Modifier.size(48.dp).clickable { icon = k }.border(if (icon == k) 2.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp))) { HabitIcon(k, 46) } } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) { iconChoices.drop(12).take(7).forEach { k -> Box(Modifier.size(48.dp).clickable { icon = k }.border(if (icon == k) 2.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp))) { HabitIcon(k, 46) } } }
    } }, confirmButton = { Button(enabled = name.isNotBlank(), onClick = { save(name.trim(), target, icon, reminder, reminderTime.trim()) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) { Text("Simpan") } }, dismissButton = { if (habit != null) TextButton(onClick = delete) { Text("Hapus") } else TextButton(onClick = cancel) { Text("Batal") } })
}

@Composable private fun SettingsDialog(vm: DaymarkViewModel, close: () -> Unit) {
    var custom by remember(vm.accentHex) { mutableStateOf(vm.accentHex) }
    var invalid by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    AlertDialog(onDismissRequest = close, title = { Text("Pengaturan", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurface) }, text = { Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Notifikasi & alarm", fontWeight = FontWeight.Bold)
        val activity = context as? MainActivity
        val notificationAllowed = if (Build.VERSION.SDK_INT >= 33) context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED else androidx.core.app.NotificationManagerCompat.from(context).areNotificationsEnabled()
        Text(if (notificationAllowed) "Notifikasi aktif. Reminder bisa tampil sesuai jadwal." else "Notifikasi belum diizinkan. Aktifkan supaya reminder bisa muncul.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        if (!notificationAllowed) {
            Button(onClick = { activity?.requestNotificationPermissionFromUi() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) { Text("Aktifkan notifikasi") }
        } else {
            TextButton(onClick = { ReminderScheduler.sendTestNotification(context) }) { Text("Kirim tes notifikasi") }
            TextButton(onClick = { ReminderScheduler.scheduleTest(context) }) { Text("Tes reminder 10 detik") }
        }
        TextButton(onClick = { context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply { putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName) }) }) { Text("Pengaturan notifikasi") }
        if (Build.VERSION.SDK_INT >= 31) {
            TextButton(onClick = { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))) }) { Text("Izin alarm presisi") }
        }
        Divider()
        Text("Tema", fontWeight = FontWeight.Bold); listOf("system" to "Ikuti sistem", "light" to "Terang", "dark" to "Gelap").forEach { (k, label) -> Row(Modifier.fillMaxWidth().clickable { vm.updateTheme(k) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(vm.theme == k, { vm.updateTheme(k) }); Text(label) } }
        Divider()
        Text("Warna aksen", fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.heightIn(max = 170.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ThemePresets.chunked(4)) { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { (label, value) -> val c = Color(value); Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(c).clickable { vm.updateAccent("#" + Integer.toHexString(value).uppercase().padStart(8, '0').takeLast(6)); custom = "#" + Integer.toHexString(value).uppercase().padStart(8, '0').takeLast(6); invalid = false }, contentAlignment = Alignment.BottomCenter) { Text(label, color = if (c.luminance() > .65f) Ink else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp)) } } } }
        }
        OutlinedTextField(custom, { custom = it.uppercase(); invalid = false }, label = { Text("Custom HEX, contoh #BDEB63") }, singleLine = true, isError = invalid)
        if (invalid) Text("Format warna tidak valid.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
        TextButton(onClick = { val ok = Regex("^#[0-9A-F]{6}$").matches(custom); if (ok) { vm.updateAccent(custom); invalid = false } else invalid = true }) { Text("Pakai warna ini") }
    } }, confirmButton = { TextButton(onClick = close) { Text("Selesai") } })
}

@Composable private fun ProfileDialog(vm: DaymarkViewModel, close: () -> Unit) {
    var n by remember { mutableStateOf(vm.name) }
    AlertDialog(onDismissRequest = close, title = { Text("Profil", fontWeight = FontWeight.Black) }, text = { OutlinedTextField(n, { n = it }, label = { Text("Nama") }, singleLine = true) }, confirmButton = { Button(onClick = { vm.updateName(n); close() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) { Text("Simpan") } })
}

@Composable private fun BackupDialog(text: String, close: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    AlertDialog(onDismissRequest = close, title = { Text("Data & Backup", fontWeight = FontWeight.Black) }, text = { Text("Backup dibuat sebagai teks JSON. Bagikan ke Drive, catatan, atau tempat aman.") }, confirmButton = { Button(onClick = { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/json"; putExtra(Intent.EXTRA_TEXT, text) }, "Bagikan backup")) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) { Text("Bagikan") } }, dismissButton = { TextButton(onClick = close) { Text("Tutup") } })
}

@Composable private fun AboutDialog(close: () -> Unit) { AlertDialog(onDismissRequest = close, title = { Text("Daymark", fontWeight = FontWeight.Black) }, text = { Column { HabitIcon("target", 70); Spacer(Modifier.height(10.dp)); Text("Planner harian + habit tracker offline. Dibuat sederhana supaya fokus ke hari yang sedang dijalani."); Spacer(Modifier.height(7.dp)); Text("Versi 2.4.2", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) } }, confirmButton = { TextButton(onClick = close) { Text("Tutup") } }) }

@Composable private fun ConfirmReset(confirm: () -> Unit, cancel: () -> Unit) { AlertDialog(onDismissRequest = cancel, title = { Text("Reset semua data?", fontWeight = FontWeight.Black) }, text = { Text("Semua To-Do, progress habit, nama, dan pengaturan akan dikembalikan ke awal.") }, confirmButton = { Button(onClick = confirm, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB8463B), contentColor = Color.White)) { Text("Reset") } }, dismissButton = { TextButton(onClick = cancel) { Text("Batal") } }) }

@Composable private fun TutorialScreen(done: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val titles = listOf("Mulai dari hari ini", "Atur To-Do + reminder", "Jaga kebiasaan", "Lihat progres")
    val bodies = listOf("Daymark membantu merapikan To-Do dan habit. Data utama tersimpan di HP dan bisa dipakai tanpa internet.", "Di Today, tekan + tugas, isi jam, lalu aktifkan Pengingat dan pilih jam reminder. Pastikan izin notifikasi sudah aktif di Pengaturan.", "Habit punya target harian. Makan 4× bisa dicatat 0/4 sampai 4/4. Pengingat harian bisa diatur dari editor habit.", "Progress merangkum minggu berjalan, penyelesaian To-Do, check-in habit, dan streak dari riwayat.")
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (page > 0) IconButton(onClick = { page-- }) { Icon(Icons.Default.ArrowBack, "Kembali") }
            Text("DAYMARK", fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurface); Spacer(Modifier.weight(1f)); if (page < 3) TextButton(onClick = done) { Text("Lewati") }
        }
        Spacer(Modifier.weight(1f)); Box(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surfaceContainerHighest), contentAlignment = Alignment.Center) { HabitIcon(listOf("journal", "target", "meal", "growth")[page], 150) }
        Spacer(Modifier.height(28.dp)); Text(titles[page], fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurface); Spacer(Modifier.height(9.dp)); Text(bodies[page], color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(22.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { repeat(4) { Box(Modifier.size(if (it == page) 24.dp else 8.dp, 8.dp).clip(RoundedCornerShape(5.dp)).background(if (it == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)) } }
        Spacer(Modifier.height(22.dp)); Button(onClick = { if (page == 3) done() else page++ }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) { Text(if (page == 3) "Mulai" else "Lanjut", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(8.dp)); Text("Data tersimpan di HP.", Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.weight(.2f))
    }
}

@Composable private fun BottomNav(selected: Screen, on: (Screen) -> Unit) { NavigationBar(containerColor = MaterialTheme.colorScheme.surface) { listOf(Screen.HOME to ("Today" to Icons.Default.Today), Screen.HABITS to ("Habits" to Icons.Default.Repeat), Screen.PROGRESS to ("Progress" to Icons.Default.Insights), Screen.MORE to ("Lainnya" to Icons.Default.MoreHoriz)).forEach { (s, pair) -> NavigationBarItem(selected = selected == s, onClick = { on(s) }, icon = { Icon(pair.second, null) }, label = { Text(pair.first, fontSize = 10.sp) }) } } }

@Composable private fun DaySwitch(date: String, prev: () -> Unit, next: () -> Unit) { Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clip(RoundedCornerShape(12.dp)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))) { IconButton(onClick = prev) { Icon(Icons.Default.ChevronLeft, "Sebelumnya") }; Text(shortDate(date), fontSize = 12.sp, fontWeight = FontWeight.Bold); IconButton(onClick = next) { Icon(Icons.Default.ChevronRight, "Berikutnya") } } }
@Composable private fun SmallButton(text: String, on: () -> Unit) { Text(text, Modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary).clickable { on() }.padding(horizontal = 12.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
@Composable private fun Section(text: String) { Text(text, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
@Composable private fun EmptyCard(title: String, body: String) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(17.dp)).padding(18.dp)) { Text(title, fontWeight = FontWeight.Bold); Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) } }
@Composable private fun CheckCircleButton(done: Boolean, on: () -> Unit) { Box(Modifier.size(28.dp).clip(CircleShape).background(if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant).border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape).clickable { on() }, contentAlignment = Alignment.Center) { if (done) Icon(Icons.Default.Check, null, Modifier.size(17.dp)) } }
@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) { Column(modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp)).padding(16.dp)) { Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Black); Spacer(Modifier.height(8.dp)); Text(value, fontSize = 26.sp, fontWeight = FontWeight.Black) } }
@Composable private fun ChartCard(tasks: List<Task>, days: List<String>) { val counts = days.map { d -> tasks.count { it.date == d && it.done } }; val max = (counts.maxOrNull() ?: 1).coerceAtLeast(1); Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp)).padding(16.dp)) { Text("Aktivitas To-Do", fontWeight = FontWeight.Bold); Spacer(Modifier.height(15.dp)); Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) { days.forEachIndexed { i, d -> Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.width(20.dp).height((counts[i] * 90f / max).coerceAtLeast(5f).dp).clip(RoundedCornerShape(6.dp)).background(if (counts[i] > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)); Spacer(Modifier.height(5.dp)); Text(SimpleDateFormat("EEE", Locale("id", "ID")).format(parseDate(d).time).take(2), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } } }
@Composable private fun InfoCard(title: String, body: String) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp)).padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, lineHeight = 18.sp) } }
@Composable private fun ProfileCard(name: String, click: () -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceContainerHighest).clickable { click() }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(50.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) { Text(name.firstOrNull()?.uppercase() ?: "K", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Black, fontSize = 20.sp) }; Spacer(Modifier.width(12.dp)); Column { Text(name, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Black, fontSize = 18.sp); Text("Edit profil", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface) } }
@Composable private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String, click: () -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(17.dp)).clickable { click() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } }

fun streakAt(h: Habit, end: String): Int { var d = end; var n = 0; while ((h.checks[d] ?: 0) >= h.target) { n++; d = shiftDate(d, -1); if (n > 366) break }; return n }
fun longestStreak(h: Habit): Int { val dates = h.checks.keys.sorted(); if (dates.isEmpty()) return 0; var best = 0; var cur = 0; var prev: String? = null; for (d in dates) { if ((h.checks[d] ?: 0) >= h.target && (prev == null || shiftDate(prev!!, 1) == d)) cur++ else if ((h.checks[d] ?: 0) >= h.target) cur = 1 else cur = 0; if (cur > best) best = cur; prev = d }; return best }
