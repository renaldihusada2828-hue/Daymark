package com.daymark.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object ReminderScheduler {
    private const val TASK_BASE = 50000
    private const val HABIT_BASE = 90000
    const val CHANNEL_ID = "daymark_reminders_v2"

    fun ensureChannel(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Daymark reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Pengingat To-Do dan habit Daymark"
                enableVibration(true)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            })
        }
    }

    fun sendTestNotification(context: Context) {
        ensureChannel(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Daymark")
            .setContentText("Notifikasi Daymark aktif dan siap digunakan.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        nm.notify(70001, notification)
    }

    fun scheduleTask(context: Context, task: Task) {
        if (!task.reminderEnabled || task.reminderTime.isBlank()) return
        val millis = nextMillis(task.date, task.reminderTime, false) ?: return
        set(context, TASK_BASE + (task.id % 40000).toInt(), millis, task.title, "Waktunya mengerjakan To-Do Daymark")
    }

    fun scheduleHabit(context: Context, habit: Habit) {
        if (!habit.reminderEnabled || habit.reminderTime.isBlank()) return
        val millis = nextMillis(todayString(), habit.reminderTime, true) ?: return
        set(context, HABIT_BASE + stableId(habit.id), millis, habit.name, "Pengingat habit harian")
    }

    fun cancelTask(context: Context, id: Long) = cancel(context, TASK_BASE + (id % 40000).toInt())
    fun cancelHabit(context: Context, id: String) = cancel(context, HABIT_BASE + stableId(id))

    fun rescheduleAll(context: Context) {
        ensureChannel(context)
        val p = context.getSharedPreferences("daymark_v21", Context.MODE_PRIVATE)
        val tasks = try { org.json.JSONArray(p.getString("tasks", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        for (i in 0 until tasks.length()) {
            val o = tasks.getJSONObject(i)
            val t = Task(o.getLong("id"), o.getString("date"), o.getString("title"), o.optString("time"), o.optBoolean("done"), o.optInt("priority",0), o.optString("habitId").takeIf { it.isNotBlank() }, o.optBoolean("reminderEnabled",false), o.optString("reminderTime"))
            if (!t.done && t.date >= todayString()) scheduleTask(context, t)
        }
        val habits = try { org.json.JSONArray(p.getString("habits", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        for (i in 0 until habits.length()) {
            val o = habits.getJSONObject(i)
            val h = Habit(o.getString("id"), o.getString("name"), o.optString("icon","other"), o.optInt("target",1), emptyMap(), o.optBoolean("reminderEnabled",false), o.optString("reminderTime","09:00"))
            scheduleHabit(context, h)
        }
    }

    private fun set(context: Context, request: Int, at: Long, title: String, body: String) {
        ensureChannel(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply { putExtra("title", title); putExtra("body", body); putExtra("habitRequest", request >= HABIT_BASE) }
        val pi = PendingIntent.getBroadcast(context, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // Reminder Daymark adalah alarm yang memang diminta user, jadi gunakan
        // AlarmClockInfo agar Android memperlakukannya sebagai alarm pengguna
        // dan tetap membangunkan perangkat pada waktu yang dijadwalkan.
        val showIntent = PendingIntent.getActivity(
            context,
            request + 200000,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent), pi)
    }

    private fun cancel(context: Context, request: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, request, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
    }

    private fun stableId(s: String): Int = (s.hashCode() and 0x7FFF)

    fun scheduleTest(context: Context) {
        ensureChannel(context)
        val at = System.currentTimeMillis() + 10_000L
        set(context, 79999, at, "Tes reminder Daymark", "Reminder real-time berhasil dijadwalkan.")
    }

    private fun nextMillis(date: String, time: String, daily: Boolean): Long? {
        val parts = time.trim().split(":")
        if (parts.size != 2) return null
        val hour = parts[0].toIntOrNull() ?: return null
        val minute = parts[1].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        val c = Calendar.getInstance()
        if (daily) { c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1) }
        else { val d = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date) } catch (_: Exception) { null } ?: return null; c.time = d; c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); if (c.timeInMillis <= System.currentTimeMillis()) return null }
        return c.timeInMillis
    }

    private fun todayString(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.ensureChannel(context)
        val title = intent.getStringExtra("title") ?: "Daymark"
        val body = intent.getStringExtra("body") ?: "Ada pengingat untukmu."
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), notification)
        // Rebuild schedules after every reminder so daily habits and future tasks stay registered.
        ReminderScheduler.rescheduleAll(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) ReminderScheduler.rescheduleAll(context)
    }
}
