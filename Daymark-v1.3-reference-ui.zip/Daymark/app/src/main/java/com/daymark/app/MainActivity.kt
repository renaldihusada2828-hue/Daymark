package com.daymark.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private val Ink = Color(0xFF18201B)
private val Paper = Color(0xFFF7F6F1)
private val Card = Color(0xFFFFFEFB)
private val Muted = Color(0xFF777B75)
private val Line = Color(0xFFE3E2DB)
private val Green = Color(0xFF416A50)
private val GreenSoft = Color(0xFFE6EEE7)
private val Lime = Color(0xFFC9F36B)
private val Cream = Color(0xFFF3EBCB)

private val ID = Locale("id", "ID")
private val FullDate = DateTimeFormatter.ofPattern("d MMMM yyyy", ID)
private val ShortDate = DateTimeFormatter.ofPattern("EEE, d MMM", ID)

private data class Task(val id: Long, val date: String, val title: String, val time: String, val priority: Int, val done: Boolean)
private data class Habit(val id: Long, val name: String, val target: String, val icon: Int, val doneDates: Set<String>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DaymarkApp(this) }
    }
}

@Composable
private fun DaymarkApp(context: Context) {
    val store = remember { LocalStore(context) }
    var tasks by remember { mutableStateOf(store.loadTasks()) }
    var habits by remember { mutableStateOf(store.loadHabits()) }
    var tab by remember { mutableIntStateOf(0) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var firstRun by remember { mutableStateOf(!store.hasSeenIntro()) }
    var showAddTask by remember { mutableStateOf(false) }
    var showAddHabit by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<Task?>(null) }
    var editingHabit by remember { mutableStateOf<Habit?>(null) }
    var deletingTask by remember { mutableStateOf<Task?>(null) }
    var deletingHabit by remember { mutableStateOf<Habit?>(null) }
    var detailHabit by remember { mutableStateOf<Habit?>(null) }
    var showReset by remember { mutableStateOf(false) }

    fun saveTasks(v: List<Task>) { tasks = v; store.saveTasks(v) }
    fun saveHabits(v: List<Habit>) { habits = v; store.saveHabits(v) }

    if (firstRun) {
        IntroScreen { store.setSeenIntro(); firstRun = false }
        return
    }

    MaterialTheme(colorScheme = lightColorScheme(background = Paper, surface = Card, primary = Green, onPrimary = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Paper) {
            Column(Modifier.fillMaxSize()) {
                TopHeader(tab, date, onSettings = { tab = 3 })
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> TodayScreen(
                            date, tasks.filter { it.date == date.toString() }, habits,
                            onPrev = { date = date.minusDays(1) }, onNext = { date = date.plusDays(1) },
                            onToday = { date = LocalDate.now() },
                            onToggleTask = { id -> saveTasks(tasks.map { if (it.id == id) it.copy(done = !it.done) else it }) },
                            onToggleHabit = { id -> saveHabits(toggleHabit(habits, id, date)) },
                            onAddTask = { showAddTask = true }, onAddHabit = { showAddHabit = true },
                            onEditTask = { editingTask = it }, onDeleteTask = { deletingTask = it },
                            onHabitDetail = { detailHabit = it }
                        )
                        1 -> HabitsScreen(habits, date, onAdd = { showAddHabit = true }, onToggle = { id -> saveHabits(toggleHabit(habits, id, date)) }, onEdit = { editingHabit = it }, onDelete = { deletingHabit = it }, onDetail = { detailHabit = it })
                        2 -> ProgressScreen(tasks, habits)
                        else -> MoreScreen(onReset = { showReset = true })
                    }
                }
                BottomBar(tab) { tab = it }
            }
        }
    }

    if (showAddTask) TaskDialog("Tambah To-Do", onDismiss = { showAddTask = false }) { title, time, priority ->
        saveTasks(tasks + Task(System.currentTimeMillis(), date.toString(), title, time, priority, false)); showAddTask = false
    }
    editingTask?.let { t -> TaskDialog("Edit To-Do", t.title, t.time, t.priority, { editingTask = null }) { title, time, priority ->
        saveTasks(tasks.map { if (it.id == t.id) it.copy(title = title, time = time, priority = priority) else it }); editingTask = null
    } }
    deletingTask?.let { t -> ConfirmDialog("Hapus tugas?", "\"${t.title}\" akan dihapus.", { deletingTask = null }) { saveTasks(tasks.filterNot { it.id == t.id }); deletingTask = null } }

    if (showAddHabit) HabitDialog("Tambah Habit", onDismiss = { showAddHabit = false }) { name, target, icon ->
        saveHabits(habits + Habit(System.currentTimeMillis(), name, target, icon, emptySet())); showAddHabit = false
    }
    editingHabit?.let { h -> HabitDialog("Edit Habit", h.name, h.target, h.icon, { editingHabit = null }) { name, target, icon ->
        saveHabits(habits.map { if (it.id == h.id) it.copy(name = name, target = target, icon = icon) else it }); editingHabit = null
    } }
    deletingHabit?.let { h -> ConfirmDialog("Hapus habit?", "Riwayat check-in ${h.name} juga akan dihapus.", { deletingHabit = null }) { saveHabits(habits.filterNot { it.id == h.id }); deletingHabit = null } }
    detailHabit?.let { h -> HabitDetailDialog(h, date, onDismiss = { detailHabit = null }) { saveHabits(toggleHabit(habits, h.id, date)); detailHabit = habits.find { it.id == h.id } } }
    if (showReset) ConfirmDialog("Reset semua data?", "Semua tugas, habit, dan riwayat akan dihapus.", { showReset = false }) { saveTasks(emptyList()); saveHabits(emptyList()); showReset = false }
}

@Composable private fun IntroScreen(onStart: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Paper).padding(24.dp)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(90.dp))
            Box(Modifier.size(92.dp).clip(CircleShape).background(GreenSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Spa, null, tint = Green, modifier = Modifier.size(46.dp))
            }
            Spacer(Modifier.height(22.dp)); Text("Daymark", fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text("Small steps.\nBig changes.", color = Muted, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 10.dp))
            Spacer(Modifier.weight(1f))
            Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(32.dp)).background(GreenSoft), contentAlignment = Alignment.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Bottom) {
                    repeat(5) { i -> Box(Modifier.width(38.dp).height((45 + i * 18).dp).clip(RoundedCornerShape(12.dp)).background(if (i == 4) Green else Color(0xFFB7CCBC))) }
                }
            }
            Spacer(Modifier.height(28.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Mulai", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable private fun TopHeader(tab: Int, date: LocalDate, onSettings: () -> Unit) {
    Column(Modifier.padding(horizontal = 22.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Daymark", fontSize = 25.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Pengaturan", tint = Ink) }
        }
        when (tab) {
            0 -> {
                Text("Selamat pagi,", color = Muted, fontSize = 14.sp)
                Text("Semangat hari ini!", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(date.format(FullDate), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            1 -> { Text("Habit", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("Konsisten, bukan sempurna.", color = Muted, fontSize = 13.sp) }
            2 -> { Text("Progress", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("Lihat pola, bukan sekadar angka.", color = Muted, fontSize = 13.sp) }
            else -> { Text("Lainnya", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("Pengaturan sederhana.", color = Muted, fontSize = 13.sp) }
        }
    }
}

@Composable private fun TodayScreen(date: LocalDate, tasks: List<Task>, habits: List<Habit>, onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit, onToggleTask: (Long) -> Unit, onToggleHabit: (Long) -> Unit, onAddTask: () -> Unit, onAddHabit: () -> Unit, onEditTask: (Task) -> Unit, onDeleteTask: (Task) -> Unit, onHabitDetail: (Habit) -> Unit) {
    val done = tasks.count { it.done }
    val rate = if (tasks.isEmpty()) 0 else done * 100 / tasks.size
    LazyColumn(contentPadding = PaddingValues(start = 22.dp, end = 22.dp, bottom = 26.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                DaySwitch(date, onPrev, onNext); Spacer(Modifier.weight(1f)); if (date != LocalDate.now()) Text("Hari ini", Modifier.clip(RoundedCornerShape(10.dp)).background(Ink).clickable { onToday() }.padding(horizontal = 10.dp, vertical = 7.dp), color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        item { TodayProgress(done, tasks.size, rate) }
        item { SectionHeader("TO-DO HARI INI", "Tambah", onAddTask) }
        if (tasks.isEmpty()) item { EmptyCard("Belum ada tugas", "Tambahkan satu hal kecil untuk hari ini.") }
        items(tasks, key = { it.id }) { TaskCard(it, onToggleTask, onEditTask, onDeleteTask) }
        item { SectionHeader("HABIT", "Tambah", onAddHabit) }
        if (habits.isEmpty()) item { EmptyCard("Belum ada habit", "Buat rutinitas kecil yang bisa kamu ulang.") }
        items(habits, key = { it.id }) { HabitCard(it, date, onToggleHabit, onHabitDetail) }
    }
}

@Composable private fun DaySwitch(date: LocalDate, prev: () -> Unit, next: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(13.dp)).border(1.dp, Line, RoundedCornerShape(13.dp)), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = prev, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.ChevronLeft, null, tint = Muted) }
        Text(date.format(ShortDate), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = next, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.ChevronRight, null, tint = Muted) }
    }
}

@Composable private fun TodayProgress(done: Int, total: Int, rate: Int) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(20.dp)).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Progress Hari Ini", fontSize = 12.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("$done/$total", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp)); LinearProgressIndicator({ rate / 100f }, Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = Green, trackColor = GreenSoft)
        Spacer(Modifier.height(13.dp)); Row { Metric("$done", "Task selesai"); Spacer(Modifier.width(32.dp)); Metric("${if (total == 0) 0 else 1}", "Habit hari ini") }
    }
}
@Composable private fun Metric(value: String, label: String) { Column { Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black); Text(label, color = Muted, fontSize = 11.sp) } }

@Composable private fun SectionHeader(title: String, action: String, onClick: () -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp); Spacer(Modifier.weight(1f)); Text(action, color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onClick() }) } }

@Composable private fun TaskCard(task: Task, onToggle: (Long) -> Unit, onEdit: (Task) -> Unit, onDelete: (Task) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(17.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        CheckCircle(task.done) { onToggle(task.id) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(task.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (task.done) Muted else Ink, textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None); if (task.time.isNotBlank()) Text(task.time, color = Muted, fontSize = 11.sp) }
        if (task.priority == 2) Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFD89A45)))
        IconButton(onClick = { onEdit(task) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Edit, "Edit", tint = Muted, modifier = Modifier.size(17.dp)) }
        IconButton(onClick = { onDelete(task) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.DeleteOutline, "Hapus", tint = Muted, modifier = Modifier.size(18.dp)) }
    }
}

@Composable private fun HabitCard(h: Habit, date: LocalDate, onToggle: (Long) -> Unit, onDetail: (Habit) -> Unit) {
    val done = date.toString() in h.doneDates; val streak = streakAsOf(date, h.doneDates)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(17.dp)).clickable { onDetail(h) }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        HabitIcon(h.icon); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(h.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(if (streak > 0) "$streak hari streak" else h.target, color = Muted, fontSize = 11.sp); WeekDots(h, date) }
        Box(Modifier.size(36.dp).clip(CircleShape).background(if (done) GreenSoft else Paper).border(1.dp, if (done) Green else Line, CircleShape).clickable { onToggle(h.id) }, contentAlignment = Alignment.Center) { if (done) Icon(Icons.Default.Check, null, tint = Green, modifier = Modifier.size(18.dp)) }
    }
}

@Composable private fun WeekDots(h: Habit, date: LocalDate) { Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 5.dp)) { (6 downTo 0).forEach { o -> val d = date.minusDays(o.toLong()); Box(Modifier.size(12.dp).clip(CircleShape).background(if (d.toString() in h.doneDates) Green else Line)) } } }

@Composable private fun HabitsScreen(habits: List<Habit>, date: LocalDate, onAdd: () -> Unit, onToggle: (Long) -> Unit, onEdit: (Habit) -> Unit, onDelete: (Habit) -> Unit, onDetail: (Habit) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Daftar Habit", fontSize = 14.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("Tambah", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { onAdd() }) } }
        item { StreakBanner(habits) }
        items(habits, key = { it.id }) { h -> HabitCard(h, date, onToggle, onDetail); Spacer(Modifier.height(0.dp)) }
        if (habits.isNotEmpty()) item { WeekOverview(habits, date) }
    }
}

@Composable private fun StreakBanner(habits: List<Habit>) { val best = habits.maxOfOrNull { currentStreak(it.doneDates) } ?: 0; Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Cream).padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("🔥", fontSize = 24.sp); Spacer(Modifier.width(12.dp)); Column { Text("Streak", fontWeight = FontWeight.Bold); Text("$best hari", fontSize = 20.sp, fontWeight = FontWeight.Black) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } }

@Composable private fun WeekOverview(habits: List<Habit>, date: LocalDate) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp)) { Text("7 HARI TERAKHIR", fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, color = Muted); Spacer(Modifier.height(12.dp)); habits.forEachIndexed { index, h -> Row(verticalAlignment = Alignment.CenterVertically) { Text(h.name, Modifier.width(105.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1); (6 downTo 0).forEach { o -> val d = date.minusDays(o.toLong()); Box(Modifier.padding(horizontal = 3.dp).size(20.dp).clip(RoundedCornerShape(6.dp)).background(if (d.toString() in h.doneDates) Green else Line), contentAlignment = Alignment.Center) { if (d.toString() in h.doneDates) Text("✓", fontSize = 9.sp, color = Color.White) } }; }; if (index != habits.lastIndex) Spacer(Modifier.height(9.dp)) } } }

@Composable private fun ProgressScreen(tasks: List<Task>, habits: List<Habit>) {
    val today = LocalDate.now(); val start = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)); val days = (0..6).map { start.plusDays(it.toLong()) }; val weekTasks = tasks.filter { runCatching { LocalDate.parse(it.date) }.getOrNull() in days }; val taskRate = if (weekTasks.isEmpty()) 0 else weekTasks.count { it.done } * 100 / weekTasks.size; val checks = habits.sumOf { h -> days.count { it.toString() in h.doneDates } }; val possible = habits.size * 7; val habitRate = if (possible == 0) 0 else checks * 100 / possible
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text("MINGGU INI", fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = Muted) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) { StatCard("Tingkat Penyelesaian To-Do", "$taskRate%", Modifier.weight(1f)); StatCard("Habit Check-in", "$habitRate%", Modifier.weight(1f)) } }
        item { Text("AKTIVITAS HARIAN", fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = Muted) }
        item { ActivityChart(days, tasks, habits) }
        item { Text("STREAK", fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = Muted) }
        items(habits.sortedByDescending { currentStreak(it.doneDates) }, key = { it.id }) { h -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(17.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(40.dp).clip(CircleShape).background(GreenSoft), contentAlignment = Alignment.Center) { Text(currentStreak(h.doneDates).toString(), fontWeight = FontWeight.Black, color = Green) }; Spacer(Modifier.width(12.dp)); Text(h.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("hari", color = Muted, fontSize = 11.sp) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) { StatCard("Total Task", tasks.size.toString(), Modifier.weight(1f)); StatCard("Total Habit", habits.size.toString(), Modifier.weight(1f)) } }
    }
}

@Composable private fun ActivityChart(days: List<LocalDate>, tasks: List<Task>, habits: List<Habit>) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) { days.forEach { d -> val v = (tasks.count { it.date == d.toString() && it.done } + habits.count { d.toString() in it.doneDates }).coerceAtMost(7); Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) { Box(Modifier.width(25.dp).height((22 + v * 10).dp).clip(RoundedCornerShape(7.dp)).background(if (d == LocalDate.now()) Ink else if (v > 0) Green else Line)); Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).take(2), fontSize = 9.sp, color = Muted) } } } }

@Composable private fun MoreScreen(onReset: () -> Unit) { LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { ProfileCard() }; item { SettingRow(Icons.Default.Settings, "Pengaturan", "Atur aplikasi") }; item { SettingRow(Icons.Default.Backup, "Data & Backup", "Simpan data secara lokal") }; item { SettingRow(Icons.Default.Palette, "Tema", "Terang") }; item { SettingRow(Icons.Default.Info, "Tentang Aplikasi", "Daymark 1.2") }; item { SettingRow(Icons.Default.StarBorder, "Beri Rating", "Bagikan pengalaman") }; item { Spacer(Modifier.height(8.dp)); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(16.dp)).clickable { onReset() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DeleteOutline, null, tint = Muted); Spacer(Modifier.width(12.dp)); Text("Hapus semua data", fontWeight = FontWeight.Bold) } }; item { Spacer(Modifier.height(12.dp)); Text("Disiplin hari ini, untuk versi terbaikmu esok.", Modifier.fillMaxWidth().background(GreenSoft).padding(22.dp), color = Green, fontSize = 12.sp) } } }
@Composable private fun ProfileCard() { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(44.dp).clip(CircleShape).background(Line), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Muted) }; Spacer(Modifier.width(12.dp)); Column { Text("Daymark User", fontWeight = FontWeight.Bold); Text("Semangat terus!", color = Muted, fontSize = 11.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } }
@Composable private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(16.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Muted); Spacer(Modifier.width(12.dp)); Column { Text(title, fontWeight = FontWeight.SemiBold); Text(body, color = Muted, fontSize = 11.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } }

@Composable private fun HabitDetailDialog(h: Habit, date: LocalDate, onDismiss: () -> Unit, onToggle: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, containerColor = Card, title = { Row(verticalAlignment = Alignment.CenterVertically) { HabitIcon(h.icon); Spacer(Modifier.width(12.dp)); Column { Text(h.name, fontWeight = FontWeight.Black); Text(h.target, color = Muted, fontSize = 11.sp) } } }, text = { Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("CHECKLIST HARI INI", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Muted, letterSpacing = 1.4.sp); WeekDots(h, date); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(if (date.toString() in h.doneDates) Green else GreenSoft).clickable { onToggle() }.padding(13.dp), horizontalArrangement = Arrangement.Center) { Text(if (date.toString() in h.doneDates) "Sudah selesai" else "Tandai selesai", color = if (date.toString() in h.doneDates) Color.White else Green, fontWeight = FontWeight.Bold) }; Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Cream).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text("🔥", fontSize = 22.sp); Spacer(Modifier.width(10.dp)); Column { Text("Streak", fontWeight = FontWeight.Bold); Text("${streakAsOf(date, h.doneDates)} hari", fontSize = 18.sp, fontWeight = FontWeight.Black) } } } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }) }

@Composable private fun HabitIcon(type: Int) { val icon = when (type) { 1 -> Icons.Default.DirectionsRun; 2 -> Icons.Default.MenuBook; 3 -> Icons.Default.Block; 4 -> Icons.Default.Nightlight; else -> Icons.Default.WaterDrop }; Box(Modifier.size(38.dp).clip(CircleShape).background(GreenSoft), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green, modifier = Modifier.size(21.dp)) } }
@Composable private fun CheckCircle(done: Boolean, onClick: () -> Unit) { Box(Modifier.size(27.dp).clip(CircleShape).background(if (done) Green else Paper).border(1.dp, if (done) Green else Line, CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) { if (done) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) } }
@Composable private fun EmptyCard(title: String, body: String) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(17.dp)).padding(18.dp)) { Text(title, fontWeight = FontWeight.Bold); Text(body, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp)) } }
@Composable private fun StatCard(label: String, value: String, modifier: Modifier) { Column(modifier.clip(RoundedCornerShape(18.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(18.dp)).padding(15.dp)) { Text(label, fontSize = 10.sp, color = Muted, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(value, fontSize = 25.sp, fontWeight = FontWeight.Black) } }

@Composable private fun SectionLabel(text: String) { Text(text, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp, color = Muted) }

@Composable private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) { Surface(shadowElevation = 5.dp, color = Card) { Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly) { NavItem("Beranda", Icons.Default.Home, selected == 0) { onSelect(0) }; NavItem("Habit", Icons.Default.Spa, selected == 1) { onSelect(1) }; NavItem("Progress", Icons.Default.BarChart, selected == 2) { onSelect(2) }; NavItem("Lainnya", Icons.Default.Menu, selected == 3) { onSelect(3) } } } }
@Composable private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) { Column(Modifier.clip(RoundedCornerShape(13.dp)).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = if (selected) Green else Muted, modifier = Modifier.size(20.dp)); Text(label, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, color = if (selected) Green else Muted) } }

@Composable private fun TaskDialog(title: String, initial: String = "", initialTime: String = "", initialPriority: Int = 0, onDismiss: () -> Unit, onSave: (String, String, Int) -> Unit) { var name by remember { mutableStateOf(initial) }; var time by remember { mutableStateOf(initialTime) }; var priority by remember { mutableIntStateOf(initialPriority) }; AlertDialog(onDismissRequest = onDismiss, containerColor = Card, title = { Text(title, fontWeight = FontWeight.Black) }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("Judul tugas", fontSize = 11.sp, fontWeight = FontWeight.Bold); OutlinedTextField(name, { name = it }, placeholder = { Text("Contoh: Kerjakan tugas") }, singleLine = true, shape = RoundedCornerShape(13.dp)); Text("Waktu (opsional)", fontSize = 11.sp, fontWeight = FontWeight.Bold); OutlinedTextField(time, { time = it }, placeholder = { Text("09:00") }, singleLine = true, shape = RoundedCornerShape(13.dp)); Text("Prioritas", fontSize = 11.sp, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Rendah", "Sedang", "Tinggi").forEachIndexed { i, s -> FilterChip(selected = priority == i, onClick = { priority = i }, label = { Text(s, fontSize = 11.sp) }) } } } }, confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(name.trim(), time.trim(), priority) }, enabled = name.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(13.dp)) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }) }

@Composable private fun HabitDialog(title: String, initial: String = "", initialTarget: String = "8 gelas/hari", initialIcon: Int = 0, onDismiss: () -> Unit, onSave: (String, String, Int) -> Unit) { var name by remember { mutableStateOf(initial) }; var target by remember { mutableStateOf(initialTarget) }; var icon by remember { mutableIntStateOf(initialIcon) }; AlertDialog(onDismissRequest = onDismiss, containerColor = Card, title = { Text(title, fontWeight = FontWeight.Black) }, text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) { Text("Nama habit", fontSize = 11.sp, fontWeight = FontWeight.Bold); OutlinedTextField(name, { name = it }, placeholder = { Text("Contoh: Minum air putih") }, singleLine = true, shape = RoundedCornerShape(13.dp)); Text("Target per hari", fontSize = 11.sp, fontWeight = FontWeight.Bold); OutlinedTextField(target, { target = it }, singleLine = true, shape = RoundedCornerShape(13.dp)); Text("Icon", fontSize = 11.sp, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { (0..4).forEach { i -> Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(if (icon == i) GreenSoft else Paper).border(1.dp, if (icon == i) Green else Line, RoundedCornerShape(11.dp)).clickable { icon = i }, contentAlignment = Alignment.Center) { HabitIcon(i) } } } } }, confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(name.trim(), target.trim(), icon) }, enabled = name.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(13.dp)) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }) }

@Composable private fun ConfirmDialog(title: String, body: String, onDismiss: () -> Unit, onConfirm: () -> Unit) { AlertDialog(onDismissRequest = onDismiss, containerColor = Card, icon = { Icon(Icons.Default.WarningAmber, null, tint = Muted) }, title = { Text(title, fontWeight = FontWeight.Black) }, text = { Text(body, color = Muted) }, confirmButton = { Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Hapus") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }) }

private fun toggleHabit(items: List<Habit>, id: Long, date: LocalDate): List<Habit> { val key = date.toString(); return items.map { if (it.id != id) it else { val set = it.doneDates.toMutableSet(); if (!set.add(key)) set.remove(key); it.copy(doneDates = set) } } }
private fun streakAsOf(date: LocalDate, dates: Set<String>): Int { var d = date; var n = 0; while (dates.contains(d.toString())) { n++; d = d.minusDays(1) }; return n }
private fun currentStreak(dates: Set<String>): Int { return streakAsOf(LocalDate.now(), dates) }

private class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("daymark", Context.MODE_PRIVATE)
    fun hasSeenIntro() = prefs.getBoolean("intro", false)
    fun setSeenIntro() { prefs.edit().putBoolean("intro", true).apply() }
    fun loadTasks(): List<Task> = try { val a = JSONArray(prefs.getString("tasks", "[]")); List(a.length()) { i -> val o = a.getJSONObject(i); Task(o.getLong("id"), o.optString("date", LocalDate.now().toString()), o.getString("title"), o.optString("time", ""), o.optInt("priority", 0), o.optBoolean("done", false)) } } catch (_: Exception) { emptyList() }
    fun saveTasks(items: List<Task>) { val a = JSONArray(); items.forEach { t -> a.put(JSONObject().apply { put("id", t.id); put("date", t.date); put("title", t.title); put("time", t.time); put("priority", t.priority); put("done", t.done) }) }; prefs.edit().putString("tasks", a.toString()).apply() }
    fun loadHabits(): List<Habit> = try { val a = JSONArray(prefs.getString("habits", "[]")); List(a.length()) { i -> val o = a.getJSONObject(i); val d = o.optJSONArray("dates") ?: JSONArray(); Habit(o.getLong("id"), o.getString("name"), o.optString("target", ""), o.optInt("icon", 0), buildSet { for (j in 0 until d.length()) add(d.getString(j)) }) } } catch (_: Exception) { emptyList() }
    fun saveHabits(items: List<Habit>) { val a = JSONArray(); items.forEach { h -> a.put(JSONObject().apply { put("id", h.id); put("name", h.name); put("target", h.target); put("icon", h.icon); put("dates", JSONArray(h.doneDates.toList())) }) }; prefs.edit().putString("habits", a.toString()).apply() }
}
