# Daymark v2.0
Native Android Kotlin + Jetpack Compose, offline-first.

## Isi awal
To-Do default sudah berisi rutinitas harian dan 4 kali makan. Habit default: makan 4x, minum 8 gelas, belajar skill, apply kerja, aktivitas fisik, beres-beres.

## Tutorial di aplikasi
Tutorial muncul saat pertama kali dibuka dan dapat dibuka lagi dari Lainnya > Tutorial.

## Build
GitHub Actions dapat mengekstrak ZIP project ini dan menjalankan Gradle 8.11.1 dengan JDK 17. JVM target Java/Kotlin disamakan ke 17.
